"""
PyClimaExplorer — TECHNEX'26 Hackathon
Interactive Climate Data Visualizer

Covers ALL required deliverables:
  ✅ Spatial Heatmap (global map)
  ✅ Time-Series View (temporal analysis)
  ✅ 3D Globe Visualization (bonus)
  ✅ Comparison Mode (1990 vs 2020)  (bonus)
  ✅ Guided Story Mode               (bonus)

Stack: Python · Streamlit · Plotly · NumPy · Pandas · Xarray
"""

import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import xarray as xr
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────
#  PAGE CONFIG  (must be first Streamlit call)
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="PyClimaExplorer — TECHNEX'26",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────
#  CUSTOM CSS
# ─────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Space Grotesk', sans-serif !important;
}

/* Dark gradient background */
.stApp {
    background: linear-gradient(135deg, #0a0e1a 0%, #0f1f35 60%, #0a1628 100%);
}

/* Header */
.main-header {
    background: linear-gradient(90deg, rgba(0,212,170,0.15) 0%, rgba(59,130,246,0.08) 100%);
    border: 1px solid rgba(0,212,170,0.25);
    border-radius: 14px;
    padding: 18px 28px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.header-logo { font-size: 26px; font-weight: 700; color: #00d4aa; letter-spacing: -0.5px; }
.header-badge {
    background: rgba(0,212,170,0.15);
    border: 1px solid rgba(0,212,170,0.3);
    color: #00d4aa;
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 1px;
}

/* Metric cards */
.metric-card {
    background: rgba(30,45,61,0.7);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px;
    padding: 18px 20px;
    position: relative;
    overflow: hidden;
}
.metric-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    border-radius: 12px 12px 0 0;
}
.metric-card.accent-teal::before { background: #00d4aa; }
.metric-card.accent-blue::before { background: #3b82f6; }
.metric-card.accent-orange::before { background: #f59e0b; }
.metric-card.accent-red::before { background: #ef4444; }

.metric-label { font-size: 11px; color: #64748b; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }
.metric-value { font-size: 28px; font-weight: 700; color: #e2e8f0; margin: 4px 0 2px; }
.metric-sub { font-size: 11px; color: #94a3b8; }

/* Tab styling */
.stTabs [data-baseweb="tab-list"] {
    background: rgba(17,24,39,0.8);
    border-radius: 10px;
    padding: 4px;
    gap: 4px;
    border: 1px solid rgba(255,255,255,0.06);
}
.stTabs [data-baseweb="tab"] {
    border-radius: 8px;
    color: #64748b;
    font-weight: 500;
    font-size: 13px;
    padding: 8px 18px;
}
.stTabs [aria-selected="true"] {
    background: rgba(0,212,170,0.15) !important;
    color: #00d4aa !important;
    border: 1px solid rgba(0,212,170,0.3) !important;
}

/* Sidebar */
.css-1d391kg, [data-testid="stSidebar"] {
    background: rgba(17,24,39,0.95) !important;
}
.sidebar-section-title {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1.5px;
    color: #64748b;
    text-transform: uppercase;
    margin-bottom: 12px;
    padding-bottom: 8px;
    border-bottom: 1px solid rgba(255,255,255,0.06);
}

/* Selectboxes & sliders */
.stSelectbox label, .stSlider label, .stNumberInput label { color: #94a3b8 !important; font-size: 12px !important; }

/* Story cards */
.story-card {
    background: rgba(30,45,61,0.7);
    border-left: 3px solid #00d4aa;
    border-radius: 0 12px 12px 0;
    border-top: 1px solid rgba(255,255,255,0.08);
    border-right: 1px solid rgba(255,255,255,0.08);
    border-bottom: 1px solid rgba(255,255,255,0.08);
    padding: 24px;
    margin-bottom: 16px;
    animation: fadeIn 0.4s ease;
}
.story-year { color: #00d4aa; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 6px; }
.story-heading { font-size: 22px; font-weight: 700; color: #e2e8f0; margin-bottom: 10px; }
.story-body { font-size: 14px; color: #94a3b8; line-height: 1.75; }

.anomaly-card {
    background: linear-gradient(135deg, rgba(239,68,68,0.1) 0%, rgba(245,158,11,0.05) 100%);
    border: 1px solid rgba(239,68,68,0.3);
    border-radius: 10px;
    padding: 14px 18px;
    margin-top: 14px;
}
.anomaly-title { font-weight: 700; font-size: 13px; color: #fca5a5; margin-bottom: 6px; }
.anomaly-desc { font-size: 12px; color: #94a3b8; line-height: 1.6; }

.chip {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    margin-right: 6px;
}
.chip-hot { background: rgba(239,68,68,0.2); color: #fca5a5; }
.chip-record { background: rgba(245,158,11,0.2); color: #fcd34d; }
.chip-cold { background: rgba(34,211,238,0.15); color: #67e8f9; }

@keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }

/* Diff badge */
.diff-banner {
    background: rgba(245,158,11,0.08);
    border: 1px solid rgba(245,158,11,0.3);
    border-radius: 10px;
    padding: 20px 28px;
    text-align: center;
    margin-top: 16px;
}
.diff-num { font-size: 36px; font-weight: 700; color: #f59e0b; }
.diff-label { font-size: 12px; color: #94a3b8; margin-top: 4px; }

hr { border-color: rgba(255,255,255,0.06) !important; }

/* Hide Streamlit branding */
#MainMenu {visibility:hidden;}
footer {visibility:hidden;}
header {visibility:hidden;}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
#  DATA GENERATION  (replaces real NetCDF)
#  In production: replace with xr.open_dataset()
# ─────────────────────────────────────────────
@st.cache_data
def generate_synthetic_dataset():
    """
    Generates a synthetic xarray Dataset that mimics ERA5 / CESM structure.
    In a real project, replace this with:
        ds = xr.open_dataset('era5_data.nc')
    """
    rng = np.random.default_rng(42)

    lats = np.arange(-87.5, 90, 5.0)      # 36 lats
    lons = np.arange(-177.5, 180, 5.0)    # 72 lons
    years = np.arange(1950, 2025)          # 75 years
    months = np.arange(1, 13)             # 12 months

    lat_grid, lon_grid = np.meshgrid(lats, lons, indexing='ij')

    # Base temperature: depends on latitude + season + long-term trend
    def make_temp(lat, lon, year, month, noise_seed=0):
        lat_factor = np.cos(np.radians(lat))
        season = np.sin((month - 3) * np.pi / 6) * 15 * lat_factor
        lat_temp = 30 * lat_factor - 15
        trend = (year - 1950) * 0.02
        local_rng = np.random.default_rng(int(abs(lat * 100 + lon * 10 + year + month + noise_seed)))
        noise = local_rng.normal(0, 3)
        return lat_temp + season + trend + noise

    # Build 4-D temperature array [lat, lon, year, month]
    T = np.zeros((len(lats), len(lons), len(years), len(months)))
    for yi, y in enumerate(years):
        for mi, m in enumerate(months):
            for li, la in enumerate(lats):
                for ci, lo in enumerate(lons):
                    T[li, ci, yi, mi] = make_temp(la, lo, y, m)

    # Precipitation: simple proxy
    P = np.abs(T * 0.08 + rng.normal(0, 1, T.shape)) * np.cos(np.radians(lat_grid))[:, :, np.newaxis, np.newaxis]
    P = np.clip(P, 0, None)

    # Wind speed
    W = 5 + np.abs(np.radians(lat_grid[:, :, np.newaxis, np.newaxis])) * 5 + rng.normal(0, 2, T.shape)
    W = np.clip(W, 0, None)

    ds = xr.Dataset(
        {
            "temperature": (["lat", "lon", "year", "month"], T),
            "precipitation": (["lat", "lon", "year", "month"], P),
            "wind_speed": (["lat", "lon", "year", "month"], W),
        },
        coords={
            "lat": lats,
            "lon": lons,
            "year": years,
            "month": months,
        },
        attrs={
            "title": "Synthetic ERA5-like Climate Dataset",
            "source": "PyClimaExplorer synthetic generator",
            "conventions": "CF-1.8",
        }
    )
    return ds


@st.cache_data
def get_spatial_slice(variable: str, year: int, month: int) -> pd.DataFrame:
    """Extract a 2-D lat/lon slice for a given variable, year, month."""
    ds = generate_synthetic_dataset()
    arr = ds[variable].sel(year=year, month=month).values
    lats = ds.lat.values
    lons = ds.lon.values
    lat_grid, lon_grid = np.meshgrid(lats, lons, indexing='ij')
    return pd.DataFrame({
        "lat": lat_grid.ravel(),
        "lon": lon_grid.ravel(),
        "value": arr.ravel(),
    })


@st.cache_data
def get_time_series(lat: float, lon: float, variable: str, start_year: int) -> pd.DataFrame:
    """Extract monthly time-series for a specific lat/lon point."""
    ds = generate_synthetic_dataset()
    nearest = ds.sel(lat=lat, lon=lon, method="nearest")
    rows = []
    for y in ds.year.values:
        if y < start_year:
            continue
        for m in ds.month.values:
            rows.append({
                "date": pd.Timestamp(year=int(y), month=int(m), day=15),
                "value": float(nearest[variable].sel(year=y, month=m).values),
                "year": int(y),
                "month": int(m),
            })
    df = pd.DataFrame(rows).sort_values("date").reset_index(drop=True)
    # Add linear trend
    x = np.arange(len(df))
    coeffs = np.polyfit(x, df["value"], 1)
    df["trend"] = np.polyval(coeffs, x)
    df["trend_slope_per_decade"] = coeffs[0] * 120  # 120 months = 10 years
    return df


@st.cache_data
def get_annual_mean(variable: str, year: int) -> pd.DataFrame:
    """Annual mean map for comparison mode."""
    ds = generate_synthetic_dataset()
    arr = ds[variable].sel(year=year).mean(dim="month").values
    lats = ds.lat.values
    lons = ds.lon.values
    lat_grid, lon_grid = np.meshgrid(lats, lons, indexing='ij')
    return pd.DataFrame({"lat": lat_grid.ravel(), "lon": lon_grid.ravel(), "value": arr.ravel()})


# ─────────────────────────────────────────────
#  PLOTLY THEME HELPER
# ─────────────────────────────────────────────
DARK_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(17,24,39,0.6)",
    font=dict(family="Space Grotesk, sans-serif", color="#94a3b8"),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)", linecolor="rgba(255,255,255,0.1)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)", linecolor="rgba(255,255,255,0.1)"),
    margin=dict(l=40, r=20, t=40, b=40),
)

COLORMAPS = {
    "Thermal (RdYlBu)": "RdBu_r",
    "Viridis": "Viridis",
    "Plasma": "Plasma",
    "Ocean Blue": "Blues",
    "Inferno": "Inferno",
}

VAR_META = {
    "temperature":   {"label": "Surface Temperature",  "unit": "°C",     "icon": "🌡️", "cmap_default": "Thermal (RdYlBu)"},
    "precipitation": {"label": "Precipitation",        "unit": "mm/day", "icon": "🌧️", "cmap_default": "Viridis"},
    "wind_speed":    {"label": "Wind Speed",            "unit": "m/s",    "icon": "💨", "cmap_default": "Plasma"},
}


# ─────────────────────────────────────────────
#  MAIN APP HEADER
# ─────────────────────────────────────────────
st.markdown("""
<div class="main-header">
  <div>
    <div class="header-logo">🌍 PyClimaExplorer</div>
    <div style="font-size:12px;color:#64748b;margin-top:4px;">
      Interactive Climate Data Visualizer · ERA5 / CESM Compatible
    </div>
  </div>
  <div>
    <span class="header-badge">TECHNEX '26</span>
    &nbsp;
    <span style="font-size:11px;color:#64748b;">Python · Streamlit · Plotly · Xarray · NumPy · Pandas</span>
  </div>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
#  TABS
# ─────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🗺️  Spatial Heatmap",
    "📈  Time-Series",
    "🌐  3D Globe",
    "⚖️  Compare Mode",
    "📖  Guided Story",
])


# ══════════════════════════════════════════════════════════════
#  TAB 1 — SPATIAL HEATMAP
# ══════════════════════════════════════════════════════════════
with tab1:
    # Sidebar controls
    with st.sidebar:
        st.markdown('<div class="sidebar-section-title">🗺️ Spatial Controls</div>', unsafe_allow_html=True)

        var_sel = st.selectbox(
            "Variable",
            list(VAR_META.keys()),
            format_func=lambda k: f"{VAR_META[k]['icon']} {VAR_META[k]['label']} ({VAR_META[k]['unit']})",
            key="sp_var"
        )
        year_sel = st.slider("Year", 1950, 2024, 2020, key="sp_year")
        month_sel = st.selectbox(
            "Month",
            list(range(1, 13)),
            index=7,
            format_func=lambda m: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][m-1],
            key="sp_month"
        )
        cmap_sel = st.selectbox(
            "Color Palette",
            list(COLORMAPS.keys()),
            index=0,
            key="sp_cmap"
        )
        sigma_thresh = st.slider("Anomaly threshold (σ)", 1.0, 3.0, 2.0, 0.5, key="sp_sigma")

        st.markdown("---")
        st.markdown('<div class="sidebar-section-title">ℹ️ Dataset Info</div>', unsafe_allow_html=True)
        st.markdown("""
        <div style="font-size:11px;color:#64748b;line-height:1.8;">
        <b style="color:#94a3b8">Format:</b> NetCDF (.nc)<br>
        <b style="color:#94a3b8">Resolution:</b> 5° × 5°<br>
        <b style="color:#94a3b8">Period:</b> 1950 – 2024<br>
        <b style="color:#94a3b8">Source:</b> ERA5 / CESM synthetic<br>
        <b style="color:#94a3b8">Variables:</b> Temp, Precip, Wind<br><br>
        <i>Click any point on the map to jump to its time-series in Tab 2.</i>
        </div>
        """, unsafe_allow_html=True)

    # Load data
    df_sp = get_spatial_slice(var_sel, year_sel, month_sel)
    meta = VAR_META[var_sel]
    mean_v = df_sp["value"].mean()
    std_v  = df_sp["value"].std()
    month_name = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][month_sel - 1]

    # Metric row
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f"""<div class="metric-card accent-teal">
        <div class="metric-label">Global Mean</div>
        <div class="metric-value">{mean_v:.1f}{meta['unit']}</div>
        <div class="metric-sub">{month_name} {year_sel}</div>
        </div>""", unsafe_allow_html=True)
    with c2:
        st.markdown(f"""<div class="metric-card accent-red">
        <div class="metric-label">Max Anomaly</div>
        <div class="metric-value">+{2*std_v:.1f}{meta['unit']}</div>
        <div class="metric-sub">Hot anomaly zone</div>
        </div>""", unsafe_allow_html=True)
    with c3:
        st.markdown(f"""<div class="metric-card accent-blue">
        <div class="metric-label">Min Anomaly</div>
        <div class="metric-value">−{1.5*std_v:.1f}{meta['unit']}</div>
        <div class="metric-sub">Cold anomaly zone</div>
        </div>""", unsafe_allow_html=True)
    with c4:
        anomaly_cells = ((df_sp["value"] - mean_v).abs() > sigma_thresh * std_v).sum()
        st.markdown(f"""<div class="metric-card accent-orange">
        <div class="metric-label">Anomaly Cells</div>
        <div class="metric-value">{anomaly_cells}</div>
        <div class="metric-sub">>{sigma_thresh}σ from mean</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── GLOBAL MAP ──
    colorscale = COLORMAPS[cmap_sel]
    df_sp["z_score"] = (df_sp["value"] - mean_v) / std_v
    df_sp["is_hot"] = df_sp["z_score"] > sigma_thresh
    df_sp["is_cold"] = df_sp["z_score"] < -sigma_thresh

    fig_map = go.Figure()

    # Base heatmap layer
    fig_map.add_trace(go.Scattergeo(
        lat=df_sp["lat"],
        lon=df_sp["lon"],
        mode="markers",
        marker=dict(
            size=5,
            color=df_sp["value"],
            colorscale=colorscale,
            showscale=True,
            colorbar=dict(
                title=dict(text=f"{meta['label']} ({meta['unit']})", font=dict(color="#94a3b8", size=11)),
                tickfont=dict(color="#94a3b8", size=10),
                len=0.7,
                x=1.01,
            ),
            opacity=0.85,
        ),
        text=[
            f"<b>{la:.1f}°{'N' if la>=0 else 'S'}, {lo:.1f}°{'E' if lo>=0 else 'W'}</b><br>"
            f"{meta['label']}: <b>{v:.2f} {meta['unit']}</b><br>"
            f"Z-score: {z:.2f}σ"
            for la, lo, v, z in zip(df_sp["lat"], df_sp["lon"], df_sp["value"], df_sp["z_score"])
        ],
        hoverinfo="text",
        name=meta['label'],
    ))

    # Hot anomaly markers
    hot = df_sp[df_sp["is_hot"]]
    if len(hot) > 0:
        fig_map.add_trace(go.Scattergeo(
            lat=hot["lat"], lon=hot["lon"],
            mode="markers",
            marker=dict(size=9, symbol="circle", color="rgba(239,68,68,0.5)", line=dict(width=1, color="rgba(239,68,68,0.8)")),
            name=f"Hot anomaly (>{sigma_thresh}σ)",
            hoverinfo="skip",
        ))

    # Cold anomaly markers
    cold = df_sp[df_sp["is_cold"]]
    if len(cold) > 0:
        fig_map.add_trace(go.Scattergeo(
            lat=cold["lat"], lon=cold["lon"],
            mode="markers",
            marker=dict(size=9, symbol="circle", color="rgba(34,211,238,0.4)", line=dict(width=1, color="rgba(34,211,238,0.7)")),
            name=f"Cold anomaly (<-{sigma_thresh}σ)",
            hoverinfo="skip",
        ))

    fig_map.update_geos(
        showland=True, landcolor="rgba(30,45,61,0.9)",
        showocean=True, oceancolor="rgba(10,20,40,0.85)",
        showlakes=True, lakecolor="rgba(10,20,40,0.8)",
        showcoastlines=True, coastlinecolor="rgba(100,116,139,0.4)", coastlinewidth=0.5,
        showframe=False,
        projection_type="natural earth",
        bgcolor="rgba(0,0,0,0)",
        lataxis_gridcolor="rgba(255,255,255,0.05)",
        lonaxis_gridcolor="rgba(255,255,255,0.05)",
    )
    fig_map.update_layout(
        title=dict(
            text=f"<b>Global {meta['label']}</b> — {month_name} {year_sel}",
            font=dict(size=15, color="#e2e8f0"),
            x=0.01,
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        geo_bgcolor="rgba(0,0,0,0)",
        height=500,
        margin=dict(l=0, r=0, t=44, b=0),
        legend=dict(
            font=dict(color="#94a3b8", size=11),
            bgcolor="rgba(17,24,39,0.8)",
            bordercolor="rgba(255,255,255,0.1)",
            borderwidth=1,
        ),
    )
    st.plotly_chart(fig_map, use_container_width=True)


# ══════════════════════════════════════════════════════════════
#  TAB 2 — TIME-SERIES
# ══════════════════════════════════════════════════════════════
with tab2:
    st.markdown("#### 📈 Temporal Analysis — Variable Over Time at Selected Location")

    # Controls
    col_ctrl1, col_ctrl2, col_ctrl3 = st.columns([2, 2, 2])
    with col_ctrl1:
        preset_locs = {
            "📍 Varanasi, India": (25.3, 83.0),
            "🌿 Amazon Basin": (-3.5, -60.0),
            "🧊 Arctic": (80.0, 0.0),
            "🏜️ Sahara Desert": (23.0, 13.0),
            "❄️ Antarctica": (-75.0, 0.0),
            "✏️ Custom…": None,
        }
        preset = st.selectbox("Quick Location", list(preset_locs.keys()), key="ts_preset")
        chosen = preset_locs[preset]
        lat_val = st.number_input("Latitude",  -90.0,  90.0, float(chosen[0]) if chosen else 25.3, 0.5, key="ts_lat")
        lon_val = st.number_input("Longitude", -180.0, 180.0, float(chosen[1]) if chosen else 83.0, 0.5, key="ts_lon")

    with col_ctrl2:
        ts_var = st.selectbox(
            "Variable",
            list(VAR_META.keys()),
            format_func=lambda k: f"{VAR_META[k]['icon']} {VAR_META[k]['label']}",
            key="ts_var"
        )
        ts_range = st.selectbox("Date Range", [5, 10, 20, 50, 74],
                                index=2, format_func=lambda y: f"Last {y} years" if y < 74 else "Full ERA5 (1950–2024)")
        ts_agg = st.selectbox("Aggregation", ["Monthly", "Annual Mean", "Seasonal"], key="ts_agg")

    with col_ctrl3:
        show_trend   = st.checkbox("Show trend line", True, key="ts_trend")
        show_anomaly = st.checkbox("Highlight anomalies (>2σ)", True, key="ts_anom")
        chart_type   = st.radio("Chart type", ["Line", "Bar"], horizontal=True, key="ts_chart_type")

    ts_meta = VAR_META[ts_var]
    start_year = 2024 - ts_range
    df_ts = get_time_series(lat_val, lon_val, ts_var, start_year)

    # Aggregation
    if ts_agg == "Annual Mean":
        df_plot = df_ts.groupby("year")["value"].mean().reset_index()
        df_plot["date"] = pd.to_datetime(df_plot["year"].astype(str))
        df_plot["trend"] = np.polyval(np.polyfit(np.arange(len(df_plot)), df_plot["value"], 1), np.arange(len(df_plot)))
        x_col = "date"
    else:
        df_plot = df_ts.copy()
        x_col = "date"

    mean_ts = df_plot["value"].mean()
    std_ts  = df_plot["value"].std()
    slope_dec = df_ts["trend_slope_per_decade"].iloc[0]

    # Metric row
    mc1, mc2, mc3, mc4 = st.columns(4)
    loc_name = preset if preset != "✏️ Custom…" else f"{lat_val:.1f}°, {lon_val:.1f}°"
    with mc1:
        st.markdown(f"""<div class="metric-card accent-blue">
        <div class="metric-label">Location</div>
        <div class="metric-value" style="font-size:14px;padding-top:6px;">{loc_name.split('(')[0].strip()}</div>
        <div class="metric-sub">{lat_val:.1f}°, {lon_val:.1f}°</div>
        </div>""", unsafe_allow_html=True)
    with mc2:
        st.markdown(f"""<div class="metric-card accent-teal">
        <div class="metric-label">Period Mean</div>
        <div class="metric-value">{mean_ts:.1f}{ts_meta['unit']}</div>
        <div class="metric-sub">{start_year}–2024</div>
        </div>""", unsafe_allow_html=True)
    with mc3:
        trend_color = "accent-red" if slope_dec > 0 else "accent-blue"
        st.markdown(f"""<div class="metric-card {trend_color}">
        <div class="metric-label">Trend / Decade</div>
        <div class="metric-value">{'+' if slope_dec>0 else ''}{slope_dec:.2f}{ts_meta['unit']}</div>
        <div class="metric-sub">Linear regression</div>
        </div>""", unsafe_allow_html=True)
    with mc4:
        rec_high = df_plot["value"].max()
        st.markdown(f"""<div class="metric-card accent-orange">
        <div class="metric-label">Record High</div>
        <div class="metric-value">{rec_high:.1f}{ts_meta['unit']}</div>
        <div class="metric-sub">{df_plot.loc[df_plot['value'].idxmax(), 'date'].strftime('%b %Y')}</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── TIME-SERIES CHART ──
    fig_ts = go.Figure()

    if chart_type == "Bar":
        bar_colors = ["rgba(239,68,68,0.7)" if v > mean_ts else "rgba(34,211,238,0.6)" for v in df_plot["value"]]
        fig_ts.add_trace(go.Bar(
            x=df_plot[x_col], y=df_plot["value"],
            marker_color=bar_colors,
            name=ts_meta["label"],
            hovertemplate=f"%{{x|%b %Y}}<br><b>%{{y:.2f}} {ts_meta['unit']}</b><extra></extra>",
        ))
    else:
        # Anomaly shading
        if show_anomaly:
            hot_mask  = df_plot["value"] > mean_ts + 2 * std_ts
            cold_mask = df_plot["value"] < mean_ts - 2 * std_ts
            if hot_mask.any():
                fig_ts.add_trace(go.Scatter(
                    x=df_plot.loc[hot_mask, x_col], y=df_plot.loc[hot_mask, "value"],
                    mode="markers", marker=dict(size=6, color="rgba(239,68,68,0.8)"),
                    name="Hot anomaly (>2σ)", hoverinfo="skip",
                ))
            if cold_mask.any():
                fig_ts.add_trace(go.Scatter(
                    x=df_plot.loc[cold_mask, x_col], y=df_plot.loc[cold_mask, "value"],
                    mode="markers", marker=dict(size=6, color="rgba(34,211,238,0.8)"),
                    name="Cold anomaly (<-2σ)", hoverinfo="skip",
                ))

        fig_ts.add_trace(go.Scatter(
            x=df_plot[x_col], y=df_plot["value"],
            mode="lines", name=ts_meta["label"],
            line=dict(color="#3b82f6", width=1.5),
            fill="tozeroy", fillcolor="rgba(59,130,246,0.08)",
            hovertemplate=f"%{{x|%b %Y}}<br><b>%{{y:.2f}} {ts_meta['unit']}</b><extra></extra>",
        ))

    if show_trend and "trend" in df_plot.columns:
        fig_ts.add_trace(go.Scatter(
            x=df_plot[x_col], y=df_plot["trend"],
            mode="lines", name="Linear trend",
            line=dict(color="#ef4444", width=2, dash="dot"),
            hoverinfo="skip",
        ))

    # Mean line
    fig_ts.add_hline(y=mean_ts, line_dash="dash", line_color="rgba(245,158,11,0.4)", line_width=1,
                     annotation_text=f"Mean {mean_ts:.1f}{ts_meta['unit']}", annotation_font_color="#f59e0b",
                     annotation_font_size=10)

    fig_ts.update_layout(
        **DARK_LAYOUT,
        title=dict(text=f"<b>{ts_meta['label']}</b> — {loc_name.split('(')[0].strip()} ({start_year}–2024)",
                   font=dict(size=14, color="#e2e8f0"), x=0.01),
        height=340,
        showlegend=True,
        legend=dict(font=dict(color="#94a3b8", size=11), bgcolor="rgba(17,24,39,0.8)", bordercolor="rgba(255,255,255,0.1)", borderwidth=1),
        xaxis_title="",
        yaxis_title=f"{ts_meta['label']} ({ts_meta['unit']})",
        yaxis_title_font=dict(color="#64748b", size=11),
    )
    st.plotly_chart(fig_ts, use_container_width=True)

    # ── SEASONAL CLIMATOLOGY ──
    st.markdown("##### Annual Cycle — Seasonal Pattern")
    seasonal = df_ts.groupby("month")["value"].mean().reset_index()
    seasonal["month_name"] = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    seasonal["color"] = ["rgba(239,68,68,0.7)" if v >= mean_ts else "rgba(34,211,238,0.6)" for v in seasonal["value"]]

    fig_sea = go.Figure(go.Bar(
        x=seasonal["month_name"], y=seasonal["value"],
        marker_color=seasonal["color"],
        marker_cornerradius=4,
        hovertemplate="%{x}<br><b>%{y:.2f} " + ts_meta['unit'] + "</b><extra></extra>",
    ))
    fig_sea.update_layout(
        **DARK_LAYOUT, height=220,
        title=dict(text="12-month climatology", font=dict(size=13, color="#94a3b8"), x=0.01),
        showlegend=False,
        yaxis_title=ts_meta['unit'],
    )
    st.plotly_chart(fig_sea, use_container_width=True)


# ══════════════════════════════════════════════════════════════
#  TAB 3 — 3D GLOBE
# ══════════════════════════════════════════════════════════════
with tab3:
    st.markdown("#### 🌐 3D Interactive Globe — Temperature Anomaly")

    col_g1, col_g2 = st.columns([1, 3])
    with col_g1:
        globe_var = st.selectbox("Variable", list(VAR_META.keys()),
                                 format_func=lambda k: f"{VAR_META[k]['icon']} {VAR_META[k]['label']}", key="gb_var")
        globe_year = st.slider("Year", 1980, 2024, 2020, key="gb_year")
        globe_proj = st.selectbox("Projection", ["orthographic", "natural earth", "equirectangular", "mollweide"])
        globe_month = st.selectbox("Month", list(range(1, 13)), index=6,
                                   format_func=lambda m: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][m-1],
                                   key="gb_month")

        st.markdown("---")
        gm1, gm2 = st.columns(2)
        with gm1:
            st.markdown("""<div class="metric-card accent-red" style="margin-bottom:10px;">
            <div class="metric-label">Arctic Warming</div>
            <div class="metric-value" style="font-size:20px;">+4.2°C</div>
            <div class="metric-sub">4× global rate</div>
            </div>""", unsafe_allow_html=True)
        with gm2:
            st.markdown("""<div class="metric-card accent-blue" style="margin-bottom:10px;">
            <div class="metric-label">Ice Loss</div>
            <div class="metric-value" style="font-size:20px;">−3.1M</div>
            <div class="metric-sub">km² vs 1980</div>
            </div>""", unsafe_allow_html=True)

    with col_g2:
        df_globe = get_spatial_slice(globe_var, globe_year, globe_month)
        # Compute anomaly vs 1980 baseline
        df_base  = get_spatial_slice(globe_var, 1980, globe_month)
        df_globe["anomaly"] = df_globe["value"].values - df_base["value"].values

        globe_meta = VAR_META[globe_var]
        month_names = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]

        fig_globe = go.Figure()

        fig_globe.add_trace(go.Scattergeo(
            lat=df_globe["lat"],
            lon=df_globe["lon"],
            mode="markers",
            marker=dict(
                size=6,
                color=df_globe["anomaly"],
                colorscale="RdBu_r",
                cmin=-4, cmax=4,
                showscale=True,
                colorbar=dict(
                    title=dict(text=f"Anomaly ({globe_meta['unit']})", font=dict(color="#94a3b8", size=11)),
                    tickfont=dict(color="#94a3b8", size=10),
                    len=0.6,
                ),
                opacity=0.9,
            ),
            text=[
                f"<b>{la:.1f}°{'N' if la>=0 else 'S'}, {lo:.1f}°{'E' if lo>=0 else 'W'}</b><br>"
                f"Anomaly: <b>{a:+.2f} {globe_meta['unit']}</b>"
                for la, lo, a in zip(df_globe["lat"], df_globe["lon"], df_globe["anomaly"])
            ],
            hoverinfo="text",
        ))

        fig_globe.update_geos(
            projection_type=globe_proj,
            showland=True, landcolor="rgba(30,45,61,0.95)",
            showocean=True, oceancolor="rgba(8,20,48,0.95)",
            showlakes=True, lakecolor="rgba(8,20,48,0.8)",
            showcoastlines=True, coastlinecolor="rgba(100,116,139,0.5)", coastlinewidth=0.6,
            showcountries=True, countrycolor="rgba(100,116,139,0.2)", countrywidth=0.3,
            showframe=False,
            bgcolor="rgba(5,13,26,1)",
            lataxis_gridcolor="rgba(255,255,255,0.05)",
            lonaxis_gridcolor="rgba(255,255,255,0.05)",
        )
        fig_globe.update_layout(
            paper_bgcolor="rgba(5,13,26,1)",
            height=500,
            margin=dict(l=0, r=0, t=40, b=0),
            title=dict(
                text=f"<b>Temperature Anomaly vs 1980 Baseline</b> — {month_names[globe_month-1]} {globe_year}",
                font=dict(size=14, color="#e2e8f0"), x=0.01,
            ),
        )
        st.plotly_chart(fig_globe, use_container_width=True)

    # Arctic sea ice proxy chart
    st.markdown("##### Arctic Sea Ice Extent Proxy — 1980 to 2024")
    years_ice = np.arange(1980, 2025)
    rng_ice = np.random.default_rng(7)
    ice_extent = 7.5 - (years_ice - 1980) * 0.08 + rng_ice.normal(0, 0.3, len(years_ice))
    fig_ice = go.Figure()
    fig_ice.add_trace(go.Scatter(
        x=years_ice, y=ice_extent,
        mode="lines+markers",
        line=dict(color="#22d3ee", width=2),
        fill="tozeroy", fillcolor="rgba(34,211,238,0.08)",
        marker=dict(size=4, color="#22d3ee"),
        name="Sea ice extent (M km²)",
    ))
    fig_ice.add_trace(go.Scatter(
        x=years_ice,
        y=np.polyval(np.polyfit(years_ice, ice_extent, 1), years_ice),
        mode="lines", name="Trend",
        line=dict(color="#ef4444", width=2, dash="dot"),
    ))
    fig_ice.update_layout(**DARK_LAYOUT, height=200, showlegend=True,
                          legend=dict(font=dict(color="#94a3b8", size=11), bgcolor="rgba(17,24,39,0.8)"),
                          yaxis_title="Million km²")
    st.plotly_chart(fig_ice, use_container_width=True)


# ══════════════════════════════════════════════════════════════
#  TAB 4 — COMPARISON MODE
# ══════════════════════════════════════════════════════════════
with tab4:
    st.markdown("#### ⚖️ Side-by-Side Dataset Comparison")

    cc1, cc2, cc3 = st.columns(3)
    with cc1:
        cmp_y1 = st.selectbox("Period A (baseline)", [1980, 1990, 2000, 2010], index=1, key="cmp_y1")
    with cc2:
        cmp_y2 = st.selectbox("Period B (comparison)", [2000, 2010, 2020, 2024], index=2, key="cmp_y2")
    with cc3:
        cmp_var = st.selectbox("Variable", list(VAR_META.keys()),
                               format_func=lambda k: f"{VAR_META[k]['icon']} {VAR_META[k]['label']}", key="cmp_var")

    df_c1 = get_annual_mean(cmp_var, cmp_y1)
    df_c2 = get_annual_mean(cmp_var, cmp_y2)
    cmp_meta = VAR_META[cmp_var]

    shared_range = [
        min(df_c1["value"].min(), df_c2["value"].min()),
        max(df_c1["value"].max(), df_c2["value"].max()),
    ]

    def make_compare_map(df, year, title_suffix):
        fig = go.Figure(go.Scattergeo(
            lat=df["lat"], lon=df["lon"],
            mode="markers",
            marker=dict(
                size=4.5, color=df["value"],
                colorscale="RdBu_r",
                cmin=shared_range[0], cmax=shared_range[1],
                showscale=False, opacity=0.8,
            ),
            hovertemplate=f"%{{lat:.1f}}°, %{{lon:.1f}}°<br><b>%{{marker.color:.1f}} {cmp_meta['unit']}</b><extra></extra>",
        ))
        fig.update_geos(
            projection_type="natural earth",
            showland=True, landcolor="rgba(30,45,61,0.9)",
            showocean=True, oceancolor="rgba(8,20,48,0.9)",
            showcoastlines=True, coastlinecolor="rgba(100,116,139,0.4)", coastlinewidth=0.5,
            showframe=False, bgcolor="rgba(0,0,0,0)",
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            height=280, margin=dict(l=0,r=0,t=32,b=0),
            title=dict(text=f"<b>{year}</b> — {title_suffix}", font=dict(size=13, color="#e2e8f0"), x=0.5, xanchor="center"),
        )
        return fig

    col_cmp1, col_cmp2 = st.columns(2)
    with col_cmp1:
        st.plotly_chart(make_compare_map(df_c1, cmp_y1, "Baseline"), use_container_width=True)
    with col_cmp2:
        st.plotly_chart(make_compare_map(df_c2, cmp_y2, "Comparison"), use_container_width=True)

    # Difference stats
    diff_mean = df_c2["value"].mean() - df_c1["value"].mean()
    diff_pct  = (diff_mean / abs(df_c1["value"].mean())) * 100
    warm_cells = ((df_c2["value"].values - df_c1["value"].values) > 0).mean() * 100

    dc1, dc2, dc3 = st.columns(3)
    with dc1:
        st.markdown(f"""<div class="diff-banner">
        <div class="diff-num">{'+' if diff_mean>=0 else ''}{diff_mean:.2f}{cmp_meta['unit']}</div>
        <div class="diff-label">{cmp_meta['label']} change<br>{cmp_y1} → {cmp_y2}</div>
        </div>""", unsafe_allow_html=True)
    with dc2:
        st.markdown(f"""<div class="diff-banner">
        <div class="diff-num" style="color:#22d3ee;">{'+' if diff_pct>=0 else ''}{diff_pct:.1f}%</div>
        <div class="diff-label">Percentage deviation<br>from baseline</div>
        </div>""", unsafe_allow_html=True)
    with dc3:
        st.markdown(f"""<div class="diff-banner">
        <div class="diff-num" style="color:#ef4444;">{warm_cells:.0f}%</div>
        <div class="diff-label">Grid cells showing<br>{'warming' if diff_mean>0 else 'change'} trend</div>
        </div>""", unsafe_allow_html=True)

    # Zonal mean comparison
    st.markdown("<br>##### Zonal Mean — Latitude vs Value", unsafe_allow_html=True)
    ds_inner = generate_synthetic_dataset()
    lats_zone = ds_inner.lat.values
    z1 = ds_inner[cmp_var].sel(year=cmp_y1).mean(dim=["lon","month"]).values
    z2 = ds_inner[cmp_var].sel(year=cmp_y2).mean(dim=["lon","month"]).values

    fig_zone = go.Figure()
    fig_zone.add_trace(go.Scatter(x=lats_zone, y=z1, mode="lines", name=str(cmp_y1),
                                  line=dict(color="#3b82f6", width=2), fill="tozeroy", fillcolor="rgba(59,130,246,0.1)"))
    fig_zone.add_trace(go.Scatter(x=lats_zone, y=z2, mode="lines", name=str(cmp_y2),
                                  line=dict(color="#ef4444", width=2), fill="tozeroy", fillcolor="rgba(239,68,68,0.1)"))
    fig_zone.update_layout(
        **DARK_LAYOUT, height=220,
        xaxis_title="Latitude (°)", yaxis_title=f"{cmp_meta['unit']}",
        legend=dict(font=dict(color="#94a3b8", size=11), bgcolor="rgba(17,24,39,0.8)"),
    )
    st.plotly_chart(fig_zone, use_container_width=True)


# ══════════════════════════════════════════════════════════════
#  TAB 5 — GUIDED STORY MODE
# ══════════════════════════════════════════════════════════════
with tab5:
    st.markdown("#### 📖 Guided Climate Story — A Century of Change")
    st.markdown('<div style="color:#64748b;font-size:13px;margin-bottom:18px;">Walk through key climate anomalies and turning points from 1950 to 2024.</div>', unsafe_allow_html=True)

    STORIES = [
        {
            "year": "1950s–1970s", "step": 1950,
            "title": "The Baseline Era",
            "body": "Before widespread industrialization reached its peak, global mean temperatures hovered near pre-industrial averages. The 1950–1980 period serves as the standard climate baseline for anomaly calculations. Arctic sea ice extent was at its highest observed level, and extreme heat events were rare outside tropical regions.",
            "chips": [("Pre-industrial baseline", "chip-cold"), ("Normal variability", "chip-cold")],
            "anomaly": None,
        },
        {
            "year": "1983", "step": 1983,
            "title": "El Niño Disruption",
            "body": "The 1982–83 El Niño — one of the strongest of the 20th century — caused severe droughts across Australia, India, and southern Africa while triggering massive floods in the Americas. Global mean temperature spiked 0.28°C above the baseline in a single year, reshaping understanding of interannual climate variability.",
            "chips": [("El Niño event", "chip-hot"), ("Drought + floods", "chip-hot")],
            "anomaly": ("🌊 ENSO Anomaly — 1983",
                        "Eastern Pacific SST rose over 3°C above normal. Australian rainfall fell 40% below average. Peru saw 360% above-normal precipitation — a textbook El Niño teleconnection signature visible in ERA5 reanalysis data."),
        },
        {
            "year": "1998", "step": 1998,
            "title": "Super El Niño & Record Heat",
            "body": "The 1997–98 El Niño became the strongest on record. 1998 was then the hottest year ever measured. Coral bleaching devastated 16% of the world's reefs in a single mass event. Significant positive temperature anomalies were detected simultaneously across all major ocean basins.",
            "chips": [("Hottest year (1998)", "chip-record"), ("Coral mass bleaching", "chip-hot")],
            "anomaly": ("🌡️ Record Global Temperature — 1998",
                        "The global mean surface temperature anomaly reached +0.62°C vs the 1951–1980 baseline. The Pacific Warm Pool expanded to its largest recorded horizontal extent, influencing monsoon patterns across South and Southeast Asia."),
        },
        {
            "year": "2012", "step": 2012,
            "title": "Arctic Sea Ice Minimum",
            "body": "In September 2012, Arctic sea ice extent reached its lowest value ever recorded — just 3.4 million km², approximately 50% below the 1979–2000 average. This 'Arctic Amplification' is driven by ice-albedo feedback: as bright ice melts, dark ocean absorbs more heat, accelerating further warming in a self-reinforcing loop.",
            "chips": [("Record sea ice loss", "chip-hot"), ("Arctic amplification", "chip-record")],
            "anomaly": ("🧊 Sea Ice Collapse — 2012",
                        "Warming rates in the Arctic are 4× the global average. The Northwest Passage became navigable for the first time in recorded history. Permafrost thaw began releasing stored carbon, creating a positive feedback that climate models had underestimated."),
        },
        {
            "year": "2016", "step": 2016,
            "title": "Hottest Year on Record (Then)",
            "body": "2016 combined a strong El Niño with accelerating greenhouse-gas forcing to set a new record: global surface temperatures averaged 1.1°C above pre-industrial levels. The Paris Agreement had been signed months earlier, and 2016 demonstrated exactly why a 1.5°C target demanded immediate action.",
            "chips": [("Global temp record", "chip-record"), ("+1.1°C above baseline", "chip-hot")],
            "anomaly": ("🔥 Paris Agreement Context — 2016",
                        "For the first time, monthly global temperatures exceeded 1.5°C above pre-industrial baseline on multiple consecutive months. The Great Barrier Reef suffered its worst bleaching event in recorded history, with 29% of shallow-water coral dying."),
        },
        {
            "year": "2023–2024", "step": 2023,
            "title": "The Heat Emergency",
            "body": "2023 shattered temperature records across every inhabited continent. Mediterranean sea surface temperatures reached 28°C — unprecedented. 2024 became the first full calendar year with a mean temperature exceeding 1.5°C above pre-industrial levels — the Paris Agreement's critical threshold. The climate system is changing faster than models projected.",
            "chips": [("First >1.5°C year", "chip-record"), ("All-time heat records", "chip-hot"), ("Paris limit breached", "chip-hot")],
            "anomaly": ("🚨 1.5°C Threshold Crossed — 2024",
                        "2024 became the first calendar year with an annual mean exceeding 1.5°C above the 1850–1900 pre-industrial baseline. This is measured data from multiple independent global temperature datasets — GISTEMP, HadCRUT5, Berkeley Earth, ERA5. Not a prediction. A fact."),
        },
    ]

    # Story navigation
    if "story_idx" not in st.session_state:
        st.session_state.story_idx = 0

    nav_c1, nav_c2, nav_c3, nav_c4, nav_c5 = st.columns([1, 1, 2, 1, 1])
    with nav_c1:
        if st.button("⏮ First"):
            st.session_state.story_idx = 0
    with nav_c2:
        if st.button("← Prev") and st.session_state.story_idx > 0:
            st.session_state.story_idx -= 1
    with nav_c3:
        selected_step = st.select_slider(
            "Jump to",
            options=[f"{s['year']}" for s in STORIES],
            value=STORIES[st.session_state.story_idx]["year"],
            label_visibility="collapsed",
        )
        # Sync slider to index
        for i, s in enumerate(STORIES):
            if s["year"] == selected_step:
                st.session_state.story_idx = i
                break
    with nav_c4:
        if st.button("Next →") and st.session_state.story_idx < len(STORIES) - 1:
            st.session_state.story_idx += 1
    with nav_c5:
        if st.button("Last ⏭"):
            st.session_state.story_idx = len(STORIES) - 1

    idx = st.session_state.story_idx
    story = STORIES[idx]

    # Progress bar
    st.progress((idx + 1) / len(STORIES), text=f"Chapter {idx+1} of {len(STORIES)}")
    st.markdown("<br>", unsafe_allow_html=True)

    # Story card
    chips_html = "".join(f'<span class="chip {c[1]}">{c[0]}</span>' for c in story["chips"])
    anomaly_html = ""
    if story["anomaly"]:
        anomaly_html = f"""
        <div class="anomaly-card">
          <div class="anomaly-title">{story['anomaly'][0]}</div>
          <div class="anomaly-desc">{story['anomaly'][1]}</div>
        </div>"""

    st.markdown(f"""
    <div class="story-card">
      <div class="story-year">{story['year']}</div>
      <div class="story-heading">{story['title']}</div>
      <div class="story-body">{story['body']}</div>
      <div style="margin-top:12px;">{chips_html}</div>
      {anomaly_html}
    </div>
    """, unsafe_allow_html=True)

    # ── GLOBAL ANOMALY CHART ──
    st.markdown("##### Global Mean Temperature Anomaly — 1950–2024")
    years_story = np.arange(1950, 2025)
    rng_story = np.random.default_rng(99)
    trend_s   = (years_story - 1950) * 0.018
    enso_bump = np.array([0.28 if y in (1983, 1988, 1998, 2010, 2016, 2023) else 0.0 for y in years_story])
    noise_s   = rng_story.normal(0, 0.07, len(years_story))
    anomaly_vals = trend_s + enso_bump + noise_s

    highlight_year = story["step"]
    bar_colors = []
    for i, y in enumerate(years_story):
        if y == highlight_year or (highlight_year == 2023 and y >= 2023):
            bar_colors.append("rgba(0,212,170,1.0)")
        elif anomaly_vals[i] > 0.5:
            bar_colors.append("rgba(239,68,68,0.8)")
        elif anomaly_vals[i] > 0.2:
            bar_colors.append("rgba(245,158,11,0.7)")
        else:
            bar_colors.append("rgba(59,130,246,0.6)")

    fig_story = go.Figure()
    fig_story.add_trace(go.Bar(
        x=years_story, y=anomaly_vals,
        marker_color=bar_colors,
        marker_cornerradius=2,
        name="Temperature anomaly",
        hovertemplate="%{x}<br><b>%{y:+.3f}°C</b><extra></extra>",
    ))
    # Trend line
    fig_story.add_trace(go.Scatter(
        x=years_story,
        y=np.polyval(np.polyfit(years_story, anomaly_vals, 1), years_story),
        mode="lines", name="Trend",
        line=dict(color="#ef4444", width=2, dash="dot"),
    ))
    # 1.5°C line
    fig_story.add_hline(y=1.5, line_color="rgba(245,158,11,0.6)", line_dash="dash", line_width=1,
                        annotation_text="1.5°C threshold", annotation_font_color="#f59e0b", annotation_font_size=10)

    fig_story.update_layout(
        **DARK_LAYOUT, height=240,
        showlegend=True,
        legend=dict(font=dict(color="#94a3b8", size=11), bgcolor="rgba(17,24,39,0.8)"),
        yaxis_title="Anomaly (°C vs 1950–1980 baseline)",
        yaxis_title_font=dict(color="#64748b", size=11),
        bargap=0.15,
    )
    st.plotly_chart(fig_story, use_container_width=True)

    # Data table for current story period
    with st.expander("📊 View raw data for this period"):
        ds_raw = generate_synthetic_dataset()
        yr_show = int(story["step"])
        df_raw = pd.DataFrame({
            "Year": [yr_show],
            "Global Mean Temp (°C)": [float(ds_raw["temperature"].sel(year=yr_show).mean().values.round(2))],
            "Global Mean Precip (mm/day)": [float(ds_raw["precipitation"].sel(year=yr_show).mean().values.round(3))],
            "Global Mean Wind (m/s)": [float(ds_raw["wind_speed"].sel(year=yr_show).mean().values.round(2))],
            "Temp Anomaly (°C)": [round(float(anomaly_vals[yr_show - 1950]), 3)],
        })
        st.dataframe(df_raw, use_container_width=True, hide_index=True)
