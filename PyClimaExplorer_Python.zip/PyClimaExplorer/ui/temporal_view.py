"""
ui/temporal_view.py
───────────────────
Time-Series tab — location picker, multi-year trend plot,
seasonal climatology, and summary metrics.
"""

import numpy as np
import streamlit as st

from data.loader import (
    get_time_series, get_seasonal_climatology,
    VARIABLE_META, LOCATION_PRESETS,
)
from data.analysis import linear_trend, trend_per_decade, flag_anomalies
from plots.charts import make_time_series, make_seasonal_bar


def render_temporal_view(cfg: dict) -> None:
    # ── Location controls ─────────────────────────────────────
    col_a, col_b = st.columns([2, 3])

    with col_a:
        st.subheader("📍 Location")
        preset_names = ["Custom…"] + list(LOCATION_PRESETS.keys())
        chosen_preset = st.selectbox("Quick select", preset_names, index=1)

        if chosen_preset == "Custom…":
            lat = st.number_input("Latitude",  min_value=-90.0, max_value=90.0,  value=25.3, step=0.5)
            lon = st.number_input("Longitude", min_value=-180.0, max_value=180.0, value=83.0, step=0.5)
            loc_name = f"{lat:.1f}°, {lon:.1f}°"
        else:
            lat, lon = LOCATION_PRESETS[chosen_preset]
            loc_name = chosen_preset
            st.write(f"**{lat}°N, {lon}°E**")

    with col_b:
        st.subheader("⚙️ Options")
        c1, c2, c3 = st.columns(3)
        with c1:
            variable = st.selectbox(
                "Variable", list(VARIABLE_META.keys()),
                format_func=lambda k: VARIABLE_META[k]["label"],
            )
        with c2:
            year_range = st.selectbox(
                "Date range",
                options=[5, 10, 20, 50, 74],
                format_func=lambda y: f"Last {y} years" if y < 74 else "Full ERA5 (1950–2024)",
                index=2,
            )
        with c3:
            aggregation = st.selectbox("Aggregation", ["monthly", "annual", "seasonal"])

        chart_type = st.radio("Chart type", ["line", "bar"], horizontal=True)

    st.markdown("---")

    # ── Fetch data ────────────────────────────────────────────
    meta      = VARIABLE_META[variable]
    unit      = meta["unit"]
    start_yr  = 2024 - year_range + 1
    df        = get_time_series(lat, lon, variable, start_yr, 2024, aggregation)
    df        = flag_anomalies(df, threshold=cfg["anomaly_threshold"])
    vals      = df["value"].to_numpy()
    trend_arr, slope, r2 = linear_trend(vals)
    dec_trend = trend_per_decade(vals, steps_per_year=(12 if aggregation == "monthly" else 1))

    # ── Summary metrics ───────────────────────────────────────
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.metric("Location", loc_name, f"{lat:.1f}°N, {lon:.1f}°E")
    with m2:
        st.metric(f"Mean {meta['label']}", f"{np.mean(vals):.2f} {unit}")
    with m3:
        sign = "+" if dec_trend >= 0 else ""
        st.metric("Trend / decade", f"{sign}{dec_trend:.3f} {unit}", f"R²={r2:.2f}")
    with m4:
        hot_count = int((df["anomaly_type"] == "hot").sum())
        st.metric("Hot anomalies", f"{hot_count}", f">{cfg['anomaly_threshold']:.1f}σ events")

    # ── Time-series chart ─────────────────────────────────────
    title = f"{meta['label']} — {loc_name} ({start_yr}–2024)"
    fig_ts = make_time_series(
        df, trend_arr,
        title=title, unit=unit,
        chart_type=chart_type,
        anomaly_threshold=cfg["anomaly_threshold"],
    )
    st.plotly_chart(fig_ts, use_container_width=True)

    # ── Seasonal climatology ──────────────────────────────────
    clim_df  = get_seasonal_climatology(lat, lon, variable, start_yr, 2024)
    mean_val = float(clim_df["value"].mean())
    fig_clim = make_seasonal_bar(clim_df, mean_val, unit=unit)
    st.plotly_chart(fig_clim, use_container_width=True)

    # ── Anomaly table (expander) ──────────────────────────────
    with st.expander("📋 Show anomaly records"):
        hot_df  = df[df["anomaly_type"] == "hot"][["date", "value", "z_score"]].rename(
            columns={"value": unit, "z_score": "z-score"})
        cold_df = df[df["anomaly_type"] == "cold"][["date", "value", "z_score"]].rename(
            columns={"value": unit, "z_score": "z-score"})
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**🔴 Hot anomalies**")
            st.dataframe(hot_df.sort_values("z-score", ascending=False).head(10), use_container_width=True)
        with c2:
            st.markdown("**🔵 Cold anomalies**")
            st.dataframe(cold_df.sort_values("z-score").head(10), use_container_width=True)
