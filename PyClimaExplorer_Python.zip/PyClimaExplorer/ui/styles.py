"""
ui/styles.py
────────────
Injects custom CSS into the Streamlit page to match the
PyClimaExplorer dark-space aesthetic.
"""

import streamlit as st


_CSS = """
<style>
/* ── Fonts ────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Syne:wght@700;800&display=swap');

/* ── Root overrides ───────────────────────────────────────── */
html, body, [class*="css"] {
    font-family: 'Space Grotesk', sans-serif !important;
    background-color: #0a0e1a !important;
    color: #e2e8f0 !important;
}

/* ── Header banner ────────────────────────────────────────── */
.header-banner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0 14px;
    border-bottom: 1px solid rgba(255,255,255,0.07);
    margin-bottom: 12px;
}
.logo {
    font-family: 'Syne', sans-serif !important;
    font-size: 24px;
    font-weight: 800;
    color: #00d4aa !important;
    letter-spacing: -0.5px;
}
.badge {
    font-size: 12px;
    color: #64748b;
    background: rgba(0,212,170,0.08);
    border: 1px solid rgba(0,212,170,0.2);
    border-radius: 20px;
    padding: 4px 12px;
}

/* ── Metric cards ─────────────────────────────────────────── */
[data-testid="metric-container"] {
    background: #111827 !important;
    border: 1px solid rgba(255,255,255,0.07) !important;
    border-radius: 10px !important;
    padding: 12px 16px !important;
}
[data-testid="metric-container"] label {
    color: #64748b !important;
    font-size: 11px !important;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
[data-testid="metric-container"] [data-testid="metric-value"] {
    font-family: 'Syne', sans-serif !important;
    font-size: 26px !important;
    font-weight: 700 !important;
    color: #e2e8f0 !important;
}

/* ── Sidebar ──────────────────────────────────────────────── */
[data-testid="stSidebar"] {
    background: #111827 !important;
    border-right: 1px solid rgba(255,255,255,0.07) !important;
}
[data-testid="stSidebar"] * {
    color: #94a3b8 !important;
}

/* ── Tabs ─────────────────────────────────────────────────── */
[data-baseweb="tab-list"] {
    background: #111827 !important;
    border-bottom: 1px solid rgba(255,255,255,0.07) !important;
    gap: 0 !important;
}
[data-baseweb="tab"] {
    color: #64748b !important;
    font-weight: 500 !important;
    font-size: 13px !important;
    padding: 12px 18px !important;
}
[aria-selected="true"][data-baseweb="tab"] {
    color: #00d4aa !important;
    border-bottom: 2px solid #00d4aa !important;
    background: rgba(0,212,170,0.05) !important;
}

/* ── Buttons ──────────────────────────────────────────────── */
.stButton > button {
    background: rgba(0,212,170,0.1) !important;
    border: 1px solid rgba(0,212,170,0.3) !important;
    color: #00d4aa !important;
    font-family: 'Space Grotesk', sans-serif !important;
    font-weight: 600 !important;
    border-radius: 8px !important;
}
.stButton > button:hover {
    background: rgba(0,212,170,0.2) !important;
    border-color: #00d4aa !important;
}

/* ── Selectbox / Slider ───────────────────────────────────── */
[data-baseweb="select"] {
    background: #1a2235 !important;
    border-color: rgba(255,255,255,0.1) !important;
}
[data-testid="stSlider"] > div > div {
    background: #00d4aa !important;
}

/* ── Expander ─────────────────────────────────────────────── */
[data-testid="stExpander"] {
    background: #111827 !important;
    border: 1px solid rgba(255,255,255,0.07) !important;
    border-radius: 8px !important;
}

/* ── Divider ──────────────────────────────────────────────── */
hr { border-color: rgba(255,255,255,0.07) !important; }

/* ── Captions ─────────────────────────────────────────────── */
.stCaption { color: #64748b !important; font-size: 11px !important; }
</style>
"""


def inject_styles() -> None:
    """Inject all custom CSS into the Streamlit page."""
    st.markdown(_CSS, unsafe_allow_html=True)
