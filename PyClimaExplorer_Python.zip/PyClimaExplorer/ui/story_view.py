"""
ui/story_view.py
────────────────
Guided Story tab — curated narrative walkthrough of key climate
events 1950–2024, with an interactive anomaly stripe chart.
"""

from __future__ import annotations
import hashlib
import numpy as np
import streamlit as st
from plots.charts import make_anomaly_bar


# ── Story data ─────────────────────────────────────────────────────────────────

STORIES: list[dict] = [
    {
        "year_label": "1950s–1970s",
        "year_idx":   1965,
        "title":      "The Baseline Era",
        "body": (
            "Before widespread industrialisation reached its peak, global mean temperatures "
            "hovered near the pre-industrial average. The 1950–1980 period serves as the "
            "climate baseline for most anomaly calculations today. During this time, Arctic sea "
            "ice extent was at its highest observed level and extreme heat events were rare "
            "outside the tropics."
        ),
        "chips": [("Pre-industrial baseline", "blue"), ("Normal variability", "blue")],
        "anomaly": None,
    },
    {
        "year_label": "1983",
        "year_idx":   1983,
        "title":      "El Niño Disruption",
        "body": (
            "The 1982–83 El Niño event — one of the strongest of the 20th century — caused "
            "severe droughts across Australia, India, and southern Africa while triggering "
            "massive floods in the Americas. Global mean temperature spiked +0.28°C above "
            "baseline in a single year."
        ),
        "chips": [("El Niño event", "red"), ("Drought + floods", "red")],
        "anomaly": {
            "title": "🌊 ENSO Anomaly — 1983",
            "desc":  "Eastern Pacific SST rose over 3°C above normal. Australian rainfall fell "
                     "40% below average. Peru saw 360% above-normal precipitation — a textbook "
                     "El Niño signature.",
        },
    },
    {
        "year_label": "1998",
        "year_idx":   1998,
        "title":      "Super El Niño & Record Heat",
        "body": (
            "The 1997–98 El Niño set a new standard for extreme climate events. 1998 became "
            "the then-hottest year on record. Coral bleaching events devastated 16% of the "
            "world's coral reefs. Significant anomalies were detected across all major ocean "
            "basins simultaneously."
        ),
        "chips": [("Hottest year (1998)", "orange"), ("Coral mass bleaching", "red")],
        "anomaly": {
            "title": "🌡️ Record Global Temperature — 1998",
            "desc":  "The global mean surface temperature anomaly reached +0.62°C vs the "
                     "1951–1980 baseline. The Pacific Warm Pool expanded to its largest "
                     "recorded extent.",
        },
    },
    {
        "year_label": "2012",
        "year_idx":   2012,
        "title":      "Arctic Sea Ice Minimum",
        "body": (
            "In September 2012, Arctic sea ice extent reached its lowest value ever recorded — "
            "just 3.4 million km², about 50% below the 1979–2000 average. This 'Arctic "
            "Amplification' is driven by ice-albedo feedback: as ice melts, darker ocean "
            "absorbs more heat, accelerating further warming."
        ),
        "chips": [("Record sea ice loss", "red"), ("Arctic amplification", "orange")],
        "anomaly": {
            "title": "🧊 Sea Ice Collapse — 2012",
            "desc":  "Warming rates in the Arctic are 4× the global average. The Northwest "
                     "Passage became navigable for the first time in recorded history.",
        },
    },
    {
        "year_label": "2016",
        "year_idx":   2016,
        "title":      "Hottest Year on Record (Then)",
        "body": (
            "2016 combined a strong El Niño with accelerating greenhouse warming to produce "
            "the highest global mean temperature yet recorded. Surface temperatures averaged "
            "1.1°C above pre-industrial levels — the same threshold that would be enshrined "
            "in the Paris Agreement signed just months earlier."
        ),
        "chips": [("Global temp record", "orange"), ("+1.1°C above baseline", "red")],
        "anomaly": {
            "title": "🔥 Paris Agreement Context — 2016",
            "desc":  "Monthly global temperatures briefly exceeded +1.5°C above pre-industrial "
                     "baseline. The Great Barrier Reef suffered its worst bleaching in history.",
        },
    },
    {
        "year_label": "2023–2024",
        "year_idx":   2024,
        "title":      "The Heat Emergency",
        "body": (
            "2023 shattered temperature records across every inhabited continent. 2024 became "
            "the first year with an annual mean exceeding +1.5°C above pre-industrial levels — "
            "the Paris Agreement's critical threshold. The data tells an unmistakable story: "
            "the climate system is changing faster than models projected."
        ),
        "chips": [("First >1.5°C year", "orange"), ("All-time heat records", "red"), ("Paris limit breached", "red")],
        "anomaly": {
            "title": "🚨 1.5°C Threshold Crossed — 2024",
            "desc":  "2024 is the first calendar year with a 12-month mean exceeding +1.5°C "
                     "above the 1850–1900 pre-industrial baseline — measured across multiple "
                     "independent global surface-temperature datasets.",
        },
    },
]

# ── Synthetic global anomaly series ──────────────────────────────────────────

def _global_anomaly_series() -> tuple[list[int], list[float]]:
    years = list(range(1950, 2025))
    anomalies = []
    for y in years:
        trend = (y - 1950) * 0.016
        enso  = 0.28 if y in (1983, 1998, 2016, 2023) else 0.0
        seed  = int(hashlib.md5(str(y).encode()).hexdigest(), 16) % (2**31)
        rng   = np.random.default_rng(seed)
        noise = float(rng.normal(0, 0.07))
        anomalies.append(round(trend + enso + noise, 3))
    return years, anomalies


# ── Chip helper ───────────────────────────────────────────────────────────────

_CHIP_CSS = {
    "red":    "background:#3b0f0f;color:#fca5a5;padding:2px 10px;border-radius:20px;font-size:12px;font-weight:600;margin-right:6px;",
    "orange": "background:#3b2209;color:#fcd34d;padding:2px 10px;border-radius:20px;font-size:12px;font-weight:600;margin-right:6px;",
    "blue":   "background:#0c1f3d;color:#93c5fd;padding:2px 10px;border-radius:20px;font-size:12px;font-weight:600;margin-right:6px;",
}

def _render_chips(chips: list[tuple[str, str]]) -> str:
    return " ".join(f'<span style="{_CHIP_CSS[c]}">{label}</span>' for label, c in chips)


# ── Main render ───────────────────────────────────────────────────────────────

def render_story_view() -> None:
    st.subheader("📖 Guided Climate Story — A Century of Change")
    st.caption("Key climate anomalies and turning points from 1950 to 2024")

    # Session state for current step
    if "story_idx" not in st.session_state:
        st.session_state.story_idx = 0

    n = len(STORIES)
    idx = st.session_state.story_idx
    story = STORIES[idx]

    # ── Timeline progress ─────────────────────────────────────
    step_labels = [s["year_label"].split("–")[0].replace("s", "") for s in STORIES]
    prog_cols = st.columns(n)
    for i, (col, label) in enumerate(zip(prog_cols, step_labels)):
        with col:
            if i == idx:
                st.markdown(f"<div style='text-align:center;font-weight:700;color:#00d4aa;font-size:11px;'>●<br>{label}</div>", unsafe_allow_html=True)
            elif i < idx:
                st.markdown(f"<div style='text-align:center;color:#64748b;font-size:11px;'>✓<br>{label}</div>", unsafe_allow_html=True)
            else:
                st.markdown(f"<div style='text-align:center;color:#334155;font-size:11px;'>○<br>{label}</div>", unsafe_allow_html=True)

    st.markdown("---")

    # ── Story card ────────────────────────────────────────────
    st.markdown(f"""
<div style="border-left:3px solid #00d4aa;padding:16px 20px;background:#111827;border-radius:0 8px 8px 0;margin-bottom:12px;">
  <div style="font-family:monospace;font-size:12px;color:#00d4aa;letter-spacing:2px;">{story["year_label"]}</div>
  <div style="font-size:20px;font-weight:800;color:#e2e8f0;margin:6px 0 10px;">{story["title"]}</div>
  <div style="font-size:14px;color:#94a3b8;line-height:1.75;">{story["body"]}</div>
  <div style="margin-top:12px;">{_render_chips(story["chips"])}</div>
</div>
""", unsafe_allow_html=True)

    # ── Anomaly highlight ──────────────────────────────────────
    if story["anomaly"]:
        st.markdown(f"""
<div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.3);border-radius:8px;padding:12px 16px;margin-bottom:12px;">
  <div style="font-weight:700;color:#fca5a5;font-size:13px;margin-bottom:4px;">{story["anomaly"]["title"]}</div>
  <div style="font-size:12px;color:#94a3b8;line-height:1.65;">{story["anomaly"]["desc"]}</div>
</div>
""", unsafe_allow_html=True)

    # ── Navigation ────────────────────────────────────────────
    nav_l, nav_c, nav_r = st.columns([1, 2, 1])
    with nav_l:
        if st.button("← Previous", disabled=(idx == 0), use_container_width=True):
            st.session_state.story_idx -= 1
            st.rerun()
    with nav_c:
        st.markdown(f"<p style='text-align:center;color:#64748b;font-size:12px;padding-top:8px;'>{idx+1} / {n}</p>", unsafe_allow_html=True)
    with nav_r:
        label = "✓ Finish" if idx == n - 1 else "Next →"
        if st.button(label, disabled=(idx == n - 1), use_container_width=True):
            st.session_state.story_idx += 1
            st.rerun()

    # Step selector
    all_labels = [s["year_label"] for s in STORIES]
    jump_to = st.selectbox("Jump to event", all_labels, index=idx, label_visibility="collapsed")
    if all_labels.index(jump_to) != idx:
        st.session_state.story_idx = all_labels.index(jump_to)
        st.rerun()

    st.markdown("---")

    # ── Global anomaly chart ──────────────────────────────────
    years, anomalies = _global_anomaly_series()
    fig = make_anomaly_bar(years, anomalies, highlight_year=story["year_idx"])
    st.plotly_chart(fig, use_container_width=True)
    st.caption(f"Highlighted bar: {story['year_idx']} — {story['title']}")
