"""
ui/sidebar.py
─────────────
Renders the shared Streamlit sidebar and returns a config dict
consumed by all view modules.
"""

import streamlit as st
from data.loader import VARIABLE_META, MONTH_NAMES


def render_sidebar() -> dict:
    """
    Render sidebar controls and return shared configuration dict.

    Returns
    -------
    dict with keys:
        variable, year, month, palette, anomaly_threshold
    """
    st.markdown("### 🌍 Global Controls")
    st.caption("Settings apply to Spatial and Compare views")

    st.markdown("---")

    # Variable
    var_options = list(VARIABLE_META.keys())
    var_labels = {k: f"{v['label']} ({v['unit']})" for k, v in VARIABLE_META.items()}
    variable = st.selectbox(
        "Variable",
        options=var_options,
        format_func=lambda k: var_labels[k],
        index=0,
    )

    # Year
    year = st.slider("Year", min_value=1950, max_value=2024, value=2020)

    # Month
    month = st.selectbox(
        "Month",
        options=list(range(1, 13)),
        format_func=lambda m: MONTH_NAMES[m - 1],
        index=7,  # August
    )

    # Colour palette
    palette = st.selectbox(
        "Colour Palette",
        options=["thermal", "viridis", "plasma", "ocean"],
        format_func=lambda p: p.capitalize(),
    )

    # Anomaly threshold
    st.markdown("**Anomaly Threshold (σ)**")
    anomaly_threshold = st.slider(
        label="Anomaly threshold",
        min_value=1.0,
        max_value=3.0,
        value=2.0,
        step=0.5,
        label_visibility="collapsed",
    )
    st.caption(f"Flagging cells with |z| ≥ {anomaly_threshold:.1f}σ")

    st.markdown("---")
    st.caption("💡 Click any cell on the heatmap to jump to its time-series.")
    st.caption("📁 To load a real NetCDF file, use `data.loader.load_netcdf()`.")

    return dict(
        variable=variable,
        year=year,
        month=month,
        palette=palette,
        anomaly_threshold=anomaly_threshold,
    )
