"""
ui/spatial_view.py
──────────────────
Spatial Heatmap tab — global climate map with anomaly overlays
and summary metric cards.
"""

import numpy as np
import streamlit as st

from data.loader import get_spatial_grid, global_metrics, VARIABLE_META, MONTH_NAMES
from data.analysis import z_score_anomalies, spatial_anomaly
from plots.charts import make_heatmap


def render_spatial_view(cfg: dict) -> None:
    variable = cfg["variable"]
    year     = cfg["year"]
    month    = cfg["month"]
    palette  = cfg["palette"]
    thresh   = cfg["anomaly_threshold"]

    meta  = VARIABLE_META[variable]
    lats, lons, values = get_spatial_grid(variable, year, month)
    stats = global_metrics(variable, year, month)
    _, _, base_vals = get_spatial_grid(variable, 1990, month)
    anomaly_grid = spatial_anomaly(values, base_vals)
    anomaly_mask = z_score_anomalies(values.flatten(), thresh).reshape(values.shape)

    # ── Metric cards ─────────────────────────────────────────
    m1, m2, m3, m4 = st.columns(4)
    unit = meta["unit"]

    with m1:
        delta_sign = "+" if stats["anomaly"] >= 0 else ""
        st.metric(
            "Global Mean",
            f"{stats['mean']:.1f} {unit}",
            f"{delta_sign}{stats['anomaly']:.2f} {unit} vs 1990",
        )
    with m2:
        st.metric("Max Anomaly", f"+{anomaly_grid.max():.2f} {unit}", "Arctic amplification")
    with m3:
        st.metric("Min Anomaly", f"{anomaly_grid.min():.2f} {unit}", "Southern Ocean")
    with m4:
        st.metric("Grid Cells", f"{stats['n_cells']:,}", f"36×72 @ 5° resolution")

    st.markdown("---")

    # ── Main heatmap ──────────────────────────────────────────
    mon_name = MONTH_NAMES[month - 1]
    title    = f"Global {meta['label']} — {mon_name} {year}"

    fig = make_heatmap(
        lats, lons, values,
        title=title,
        unit=unit,
        colorscale=palette,
        anomaly_mask=anomaly_mask,
    )
    st.plotly_chart(fig, use_container_width=True)

    # ── Legend note ───────────────────────────────────────────
    col_l, col_r = st.columns([1, 2])
    with col_l:
        st.caption("🔴 Red circles = hot anomaly (>" + f"{thresh:.1f}σ)  "
                   "🔵 Blue circles = cold anomaly (<−" + f"{thresh:.1f}σ)")
    with col_r:
        st.caption(f"Baseline: 1990 · Variable: {meta['label']} · Resolution: 5° × 5°")
