"""
ui/compare_view.py
──────────────────
Compare Mode tab — side-by-side heatmaps for two periods,
delta statistics, and a zonal mean comparison chart.
"""

import numpy as np
import streamlit as st

from data.loader import get_spatial_grid, VARIABLE_META
from data.analysis import spatial_anomaly, anomaly_stats
from plots.charts import make_comparison, make_zonal_mean
from data.loader import get_zonal_mean


def render_compare_view(cfg: dict) -> None:
    st.subheader("⚖️ Side-by-Side Dataset Comparison")
    st.caption("Compare any two years / variables and see what changed")

    # ── Period selectors ──────────────────────────────────────
    col1, col2, col3 = st.columns(3)
    with col1:
        year_a = st.selectbox("Period A (baseline)", [1950, 1960, 1970, 1980, 1990, 2000, 2010], index=4)
    with col2:
        year_b = st.selectbox("Period B (comparison)", [2000, 2010, 2015, 2020, 2024], index=3)
    with col3:
        cmp_var = st.selectbox(
            "Variable",
            options=list(VARIABLE_META.keys()),
            format_func=lambda k: VARIABLE_META[k]["label"],
        )

    cmp_month  = st.slider("Month (both periods)", 1, 12, value=7)
    cmp_palette = st.select_slider(
        "Palette", options=["thermal", "viridis", "plasma", "ocean"], value="thermal"
    )

    st.markdown("---")

    # ── Fetch data ────────────────────────────────────────────
    meta         = VARIABLE_META[cmp_var]
    unit         = meta["unit"]
    lats, lons, v1 = get_spatial_grid(cmp_var, year_a, cmp_month)
    _,    _,    v2 = get_spatial_grid(cmp_var, year_b, cmp_month)
    diff          = spatial_anomaly(v2, v1)
    stats         = anomaly_stats(diff)

    # ── Delta metric cards ────────────────────────────────────
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        sign = "+" if stats["mean_anomaly"] >= 0 else ""
        st.metric(f"Mean Δ {unit}", f"{sign}{stats['mean_anomaly']:.3f}", f"{year_a} → {year_b}")
    with m2:
        st.metric("Max Warming", f"+{stats['max_anomaly']:.2f} {unit}")
    with m3:
        st.metric("Max Cooling", f"{stats['min_anomaly']:.2f} {unit}")
    with m4:
        st.metric("% Grid Cells Warming", f"{stats['pct_warming']:.1f}%")

    # ── Side-by-side heatmaps ─────────────────────────────────
    fig_cmp = make_comparison(
        lats, lons, v1, v2,
        label1=f"{year_a} — {meta['label']}",
        label2=f"{year_b} — {meta['label']}",
        unit=unit,
        colorscale=cmp_palette,
    )
    st.plotly_chart(fig_cmp, use_container_width=True)

    # ── Difference map ────────────────────────────────────────
    with st.expander("🔎 Show difference map (B − A)", expanded=True):
        from plots.charts import make_heatmap
        fig_diff = make_heatmap(
            lats, lons, diff,
            title=f"Δ {meta['label']}: {year_b} − {year_a}",
            unit=f"Δ{unit}",
            colorscale="diverge",
        )
        st.plotly_chart(fig_diff, use_container_width=True)

    # ── Zonal mean comparison ──────────────────────────────────
    st.markdown("**Zonal Mean Comparison (Latitude vs Value)**")
    df1 = get_zonal_mean(cmp_var, year_a, cmp_month)
    df2 = get_zonal_mean(cmp_var, year_b, cmp_month)
    fig_z = make_zonal_mean(df1, df2, str(year_a), str(year_b), unit=unit)
    st.plotly_chart(fig_z, use_container_width=True)
