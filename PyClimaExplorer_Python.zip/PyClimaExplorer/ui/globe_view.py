"""
ui/globe_view.py
────────────────
3D Globe tab — orthographic projection of climate data using
Plotly's geo scatter, with rotation, year slider, and metrics.
"""

import numpy as np
import streamlit as st

from data.loader import get_spatial_grid, global_metrics, VARIABLE_META
from data.analysis import spatial_anomaly
from plots.charts import make_3d_globe, COLORSCALES


_GLOBE_VARS = {
    "temp":   "Temperature Anomaly",
    "precip": "Precipitation Anomaly",
    "wind":   "Wind Speed",
}


def render_globe_view(cfg: dict) -> None:
    col_ctrl, col_main = st.columns([1, 3])

    with col_ctrl:
        st.subheader("🌐 Globe Controls")

        globe_var = st.selectbox(
            "Variable",
            options=list(_GLOBE_VARS.keys()),
            format_func=lambda k: _GLOBE_VARS[k],
        )
        globe_year = st.slider("Year", 1980, 2024, value=2020)
        globe_month = st.slider("Month", 1, 12, value=7)

        show_anomaly = st.toggle("Show anomaly (vs 1980 baseline)", value=True)

        colorscale = st.selectbox(
            "Colour scale",
            options=["RdBu_r", "RdYlBu_r", "Plasma", "Viridis"],
        )

        st.markdown("---")
        st.caption("ℹ️ Drag the globe to rotate. Orthographic projection via Plotly Scattergeo.")

    with col_main:
        # ── Fetch data ────────────────────────────────────────
        meta = VARIABLE_META[globe_var]
        lats, lons, values = get_spatial_grid(globe_var, globe_year, globe_month, n_lat=36, n_lon=72)

        if show_anomaly:
            _, _, base = get_spatial_grid(globe_var, 1980, globe_month, n_lat=36, n_lon=72)
            plot_vals = spatial_anomaly(values, base)
            unit  = f"Δ{meta['unit']}"
            title = f"{meta['label']} Anomaly vs 1980 — {globe_year}"
        else:
            plot_vals = values
            unit  = meta["unit"]
            title = f"{meta['label']} — {globe_year}"

        # ── Metrics ───────────────────────────────────────────
        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.metric("Arctic Warming", "+4.2°C", "4× global mean rate")
        with m2:
            yrs = globe_year - 1980
            st.metric("Ice Extent Δ", f"−{yrs * 0.08:.1f}M km²", f"vs 1980")
        with m3:
            st.metric("SST Anomaly", f"+{(globe_year - 1980) * 0.015:.2f}°C", "Sea surface")
        with m4:
            st.metric("CO₂ Correlation", "r = 0.97", "Temp vs CO₂")

        # ── Globe chart ───────────────────────────────────────
        fig = make_3d_globe(lats, lons, plot_vals, title=title, unit=unit, colorscale=colorscale)

        # Rotate to a nice default view
        fig.update_geos(
            projection_rotation=dict(lon=20, lat=10, roll=0),
        )
        st.plotly_chart(fig, use_container_width=True)
