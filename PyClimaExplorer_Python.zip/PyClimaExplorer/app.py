"""
PyClimaExplorer — TECHNEX'26
Main Streamlit Application Entry Point
"""

import streamlit as st

st.set_page_config(
    page_title="PyClimaExplorer — TECHNEX'26",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded",
)

from ui.sidebar import render_sidebar
from ui.spatial_view import render_spatial_view
from ui.temporal_view import render_temporal_view
from ui.globe_view import render_globe_view
from ui.compare_view import render_compare_view
from ui.story_view import render_story_view
from ui.styles import inject_styles

# ── Custom CSS ────────────────────────────────────────────────
inject_styles()

# ── Header ────────────────────────────────────────────────────
st.markdown("""
<div class="header-banner">
  <span class="logo">🌍 PyClimaExplorer</span>
  <span class="badge">TECHNEX'26 · ERA5 / CESM Interactive Visualizer</span>
</div>
""", unsafe_allow_html=True)

# ── Tab Navigation ────────────────────────────────────────────
tabs = st.tabs([
    "🗺️ Spatial Heatmap",
    "📈 Time-Series",
    "🌐 3D Globe",
    "⚖️ Compare Mode",
    "📖 Guided Story",
])

# ── Sidebar (shared controls) ─────────────────────────────────
with st.sidebar:
    shared_cfg = render_sidebar()

# ── Tab Contents ──────────────────────────────────────────────
with tabs[0]:
    render_spatial_view(shared_cfg)

with tabs[1]:
    render_temporal_view(shared_cfg)

with tabs[2]:
    render_globe_view(shared_cfg)

with tabs[3]:
    render_compare_view(shared_cfg)

with tabs[4]:
    render_story_view()
