# 🌍 PyClimaExplorer

**TECHNEX'26 · Hack It Out — Interactive Climate Data Visualizer**

A rapid-prototype web dashboard for exploring multi-dimensional climate model data
(ERA5 reanalysis / CESM NetCDF files) built with Python, Streamlit, and Plotly.

---

## Features

| Tab | Description |
|---|---|
| 🗺️ **Spatial Heatmap** | Global 2-D climate map with anomaly overlays, 5 variables, year/month controls |
| 📈 **Time-Series** | Location picker, multi-year trend + seasonal climatology, anomaly table |
| 🌐 **3D Globe** | Orthographic Plotly globe projection, draggable, anomaly mode |
| ⚖️ **Compare Mode** | Side-by-side heatmaps, difference map, zonal mean chart |
| 📖 **Guided Story** | Curated narrative of 6 climate turning points (1950–2024) |

---

## Quick Start

```bash
# 1. Clone / unzip the project
cd PyClimaExplorer

# 2. Create a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
streamlit run app.py
```

The app opens at **http://localhost:8501**.

---

## Project Structure

```
PyClimaExplorer/
├── app.py                  # Main Streamlit entry point
├── requirements.txt
├── README.md
│
├── data/
│   ├── loader.py           # NetCDF loading + synthetic data engine
│   └── analysis.py         # Trend, anomaly, zonal statistics
│
├── plots/
│   └── charts.py           # All Plotly figure builders
│
└── ui/
    ├── sidebar.py          # Shared sidebar controls
    ├── styles.py           # Custom CSS injection
    ├── spatial_view.py     # Tab 1 — Spatial Heatmap
    ├── temporal_view.py    # Tab 2 — Time-Series
    ├── globe_view.py       # Tab 3 — 3D Globe
    ├── compare_view.py     # Tab 4 — Compare Mode
    └── story_view.py       # Tab 5 — Guided Story
```

---

## Using Real NetCDF Data

The app ships with a synthetic data engine that generates physically plausible values.
To load a real `.nc` file, call `data.loader.load_netcdf()`:

```python
from data.loader import load_netcdf

lats, lons, values = load_netcdf(
    filepath="era5_2m_temperature_2020.nc",
    variable_name="t2m",   # ERA5 variable name
    time_index=0,          # which time slice
)
```

### Where to get sample data

| Dataset | URL | Variables |
|---|---|---|
| ERA5 Reanalysis | https://cds.climate.copernicus.eu | t2m, tp, u10, v10, sp |
| NCEP/NCAR Reanalysis | https://psl.noaa.gov/data/gridded/ | air, precip, slp |
| CESM Large Ensemble | https://www.cesm.ucar.edu/projects/community-projects/LENS/ | TREFHT, PRECT |
| NOAA GHCN | https://www.ncei.noaa.gov/products/land-based-station/global-historical-climatology-network-daily | Surface obs |

---

## Evaluation Checklist (TECHNEX'26)

### Phase-1 Deliverables ✅
- [x] Functional interactive web dashboard (Streamlit)
- [x] At least 2 visualization types (heatmap + time-series + globe + compare)
- [x] NetCDF input support via Xarray (`data/loader.py`)
- [x] Variable selection: Temperature, Precipitation, Wind, Pressure, Humidity
- [x] Time-range slider
- [x] Spatial view (global heatmap)
- [x] Temporal view (time-series with trend)
- [x] README with run instructions and dataset links

### Bonus Features ✅
- [x] **3D Visualization** — Orthographic globe projection (Plotly Scattergeo)
- [x] **Comparison Mode** — side-by-side heatmaps + difference map + zonal mean
- [x] **Story Mode** — 6-step guided tour of climate anomalies 1950–2024

---

## Tech Stack

- **Language**: Python 3.11+
- **Web framework**: [Streamlit](https://streamlit.io)
- **Data handling**: [Xarray](https://xarray.dev), [Pandas](https://pandas.pydata.org), [NumPy](https://numpy.org)
- **Visualization**: [Plotly](https://plotly.com/python/)
- **Statistics**: [SciPy](https://scipy.org)
- **NetCDF I/O**: [netCDF4](https://unidata.github.io/netcdf4-python/), Xarray

---

## Team

Built for **TECHNEX'26 — Hack It Out** at IIT(BHU), 14–15 March 2026.

Team size: 2–4 developers · Duration: 24 hours
