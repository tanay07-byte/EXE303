"""
plots/charts.py
───────────────
All Plotly figure builders for PyClimaExplorer.

Each function takes pre-processed data (NumPy / Pandas) and returns a
plotly.graph_objects.Figure ready to pass to st.plotly_chart().

Functions
---------
  make_heatmap()        – global 2-D climate map
  make_time_series()    – multi-layer time-series with trend overlay
  make_seasonal_bar()   – 12-month climatology bar chart
  make_zonal_mean()     – latitude vs. value line chart
  make_3d_globe()       – choropleth_geo globe projection
  make_comparison()     – side-by-side heatmaps (subplots)
  make_anomaly_bar()    – global mean anomaly bar chart (story view)
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# ── Theme constants ────────────────────────────────────────────────────────────

_BG   = "#0a0e1a"
_BG2  = "#111827"
_GRID = "rgba(255,255,255,0.06)"
_TEXT = "#94a3b8"
_FONT = dict(family="Space Grotesk, sans-serif", color=_TEXT, size=12)

_LAYOUT_BASE = dict(
    paper_bgcolor=_BG2,
    plot_bgcolor=_BG2,
    font=_FONT,
    margin=dict(l=48, r=24, t=40, b=48),
    hoverlabel=dict(bgcolor="#1e2d3d", font_size=12, font_family="Space Grotesk, sans-serif"),
)

_AXIS_STYLE = dict(
    gridcolor=_GRID,
    linecolor="rgba(255,255,255,0.1)",
    tickfont=dict(color=_TEXT, size=11),
    zerolinecolor=_GRID,
)

COLORSCALES = {
    "thermal":  "RdYlBu_r",
    "viridis":  "Viridis",
    "plasma":   "Plasma",
    "ocean":    "Blues",
    "diverge":  "RdBu_r",
}


# ── Heatmap ───────────────────────────────────────────────────────────────────

def make_heatmap(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    title: str = "Global Climate Map",
    unit: str = "°C",
    colorscale: str = "thermal",
    anomaly_mask: np.ndarray | None = None,
) -> go.Figure:
    """
    2-D global heatmap rendered as a filled contour map.

    Parameters
    ----------
    lats, lons : 1-D coordinate arrays
    values     : 2-D array (len(lats) × len(lons))
    anomaly_mask : optional 2-D bool array — cells marked True get a
                   scatter overlay for significant anomalies
    """
    cs = COLORSCALES.get(colorscale, colorscale)

    fig = go.Figure()

    # Main heatmap layer
    fig.add_trace(go.Heatmap(
        x=lons,
        y=lats,
        z=values,
        colorscale=cs,
        colorbar=dict(
            title=dict(text=unit, side="right"),
            tickfont=dict(color=_TEXT, size=10),
            bgcolor=_BG2,
            outlinecolor="rgba(255,255,255,0.1)",
            len=0.85,
        ),
        hoverongaps=False,
        hovertemplate="Lat %{y:.1f}° | Lon %{x:.1f}°<br>Value: %{z:.2f} " + unit + "<extra></extra>",
        zsmooth="best",
    ))

    # Anomaly scatter overlay
    if anomaly_mask is not None:
        hot_lats, hot_lons, cold_lats, cold_lons = [], [], [], []
        mean_v = np.nanmean(values)
        for ri, lat in enumerate(lats):
            for ci, lon in enumerate(lons):
                if anomaly_mask[ri, ci]:
                    if values[ri, ci] > mean_v:
                        hot_lats.append(lat); hot_lons.append(lon)
                    else:
                        cold_lats.append(lat); cold_lons.append(lon)

        if hot_lats:
            fig.add_trace(go.Scatter(
                x=hot_lons, y=hot_lats, mode="markers",
                marker=dict(color="rgba(239,68,68,0.5)", size=5, symbol="circle"),
                name="Hot anomaly (>2σ)", hoverinfo="skip",
            ))
        if cold_lats:
            fig.add_trace(go.Scatter(
                x=cold_lons, y=cold_lats, mode="markers",
                marker=dict(color="rgba(34,211,238,0.5)", size=5, symbol="circle"),
                name="Cold anomaly (<-2σ)", hoverinfo="skip",
            ))

    # Equator + Prime Meridian reference lines
    fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.2)", width=1, dash="dot"))
    fig.add_vline(x=0, line=dict(color="rgba(255,255,255,0.1)", width=1, dash="dot"))

    fig.update_layout(
        **_LAYOUT_BASE,
        title=dict(text=title, font=dict(size=14, color="#e2e8f0"), x=0.01),
        height=420,
        xaxis=dict(**_AXIS_STYLE, title="Longitude", range=[-180, 180],
                   tickvals=[-180,-120,-60,0,60,120,180]),
        yaxis=dict(**_AXIS_STYLE, title="Latitude",  range=[-90, 90],
                   tickvals=[-90,-60,-30,0,30,60,90]),
        legend=dict(
            orientation="h", yanchor="bottom", y=-0.25,
            font=dict(color=_TEXT, size=11),
            bgcolor="rgba(0,0,0,0)",
        ),
    )
    return fig


# ── Time-Series ───────────────────────────────────────────────────────────────

def make_time_series(
    df: pd.DataFrame,
    trend_line: np.ndarray,
    title: str = "Time-Series",
    unit: str = "°C",
    chart_type: str = "line",
    anomaly_threshold: float = 2.0,
) -> go.Figure:
    """
    Line or bar time-series with trend overlay and anomaly markers.
    """
    from data.analysis import z_scores

    fig = go.Figure()
    x = df["date"].tolist()
    y = df["value"].tolist()
    z = z_scores(np.array(y))

    # Main data trace
    if chart_type == "bar":
        colors = [
            "#ef4444" if zi > anomaly_threshold else
            "#22d3ee" if zi < -anomaly_threshold else
            "#3b82f6"
            for zi in z
        ]
        fig.add_trace(go.Bar(
            x=x, y=y, name=unit,
            marker_color=colors, opacity=0.8,
            hovertemplate="%{x}<br>%{y:.2f} " + unit + "<extra></extra>",
        ))
    else:
        fig.add_trace(go.Scatter(
            x=x, y=y, mode="lines", name=unit,
            line=dict(color="#3b82f6", width=1.5),
            fill="tozeroy", fillcolor="rgba(59,130,246,0.08)",
            hovertemplate="%{x}<br>%{y:.2f} " + unit + "<extra></extra>",
        ))
        # Anomaly markers
        hot_x = [x[i] for i, zi in enumerate(z) if zi > anomaly_threshold]
        hot_y = [y[i] for i, zi in enumerate(z) if zi > anomaly_threshold]
        cold_x = [x[i] for i, zi in enumerate(z) if zi < -anomaly_threshold]
        cold_y = [y[i] for i, zi in enumerate(z) if zi < -anomaly_threshold]
        if hot_x:
            fig.add_trace(go.Scatter(x=hot_x, y=hot_y, mode="markers", name="Hot anomaly",
                                     marker=dict(color="#ef4444", size=7, symbol="circle")))
        if cold_x:
            fig.add_trace(go.Scatter(x=cold_x, y=cold_y, mode="markers", name="Cold anomaly",
                                     marker=dict(color="#22d3ee", size=7, symbol="circle")))

    # Trend line overlay
    fig.add_trace(go.Scatter(
        x=x, y=trend_line.tolist(), mode="lines", name="Linear trend",
        line=dict(color="#ef4444", width=2, dash="dash"),
        hoverinfo="skip",
    ))

    fig.update_layout(
        **_LAYOUT_BASE,
        title=dict(text=title, font=dict(size=14, color="#e2e8f0"), x=0.01),
        height=340,
        xaxis=dict(**_AXIS_STYLE, title="Date"),
        yaxis=dict(**_AXIS_STYLE, title=unit),
        legend=dict(
            orientation="h", yanchor="bottom", y=-0.3,
            font=dict(color=_TEXT, size=11),
            bgcolor="rgba(0,0,0,0)",
        ),
    )
    return fig


# ── Seasonal climatology bar ──────────────────────────────────────────────────

def make_seasonal_bar(
    df: pd.DataFrame,
    mean_val: float,
    unit: str = "°C",
) -> go.Figure:
    """
    12-month climatology with warm/cool colouring relative to the annual mean.
    """
    colors = [
        "#ef4444" if v > mean_val else "#22d3ee"
        for v in df["value"]
    ]
    fig = go.Figure(go.Bar(
        x=df["month"],
        y=df["value"].round(2),
        marker_color=colors,
        marker_line_width=0,
        opacity=0.85,
        hovertemplate="%{x}: %{y:.2f} " + unit + "<extra></extra>",
    ))
    fig.add_hline(y=mean_val, line=dict(color="rgba(255,255,255,0.3)", width=1, dash="dot"),
                  annotation_text="Annual mean", annotation_font_color=_TEXT)
    fig.update_layout(
        **_LAYOUT_BASE,
        title=dict(text="Annual Cycle — Seasonal Climatology", font=dict(size=13, color="#e2e8f0"), x=0.01),
        height=240,
        xaxis=dict(**_AXIS_STYLE),
        yaxis=dict(**_AXIS_STYLE, title=unit),
        bargap=0.15,
    )
    return fig


# ── Zonal mean ────────────────────────────────────────────────────────────────

def make_zonal_mean(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    label1: str = "Period A",
    label2: str = "Period B",
    unit: str = "°C",
) -> go.Figure:
    """
    Latitude vs. zonal-mean comparison between two periods.
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df1["value"], y=df1["lat"], mode="lines",
        name=label1, line=dict(color="#3b82f6", width=2),
        fill="tozerox", fillcolor="rgba(59,130,246,0.12)",
        hovertemplate="Lat %{y:.1f}°: %{x:.2f} " + unit + "<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=df2["value"], y=df2["lat"], mode="lines",
        name=label2, line=dict(color="#ef4444", width=2),
        fill="tozerox", fillcolor="rgba(239,68,68,0.12)",
        hovertemplate="Lat %{y:.1f}°: %{x:.2f} " + unit + "<extra></extra>",
    ))
    fig.update_layout(
        **_LAYOUT_BASE,
        title=dict(text="Zonal Mean Comparison", font=dict(size=13, color="#e2e8f0"), x=0.01),
        height=280,
        xaxis=dict(**_AXIS_STYLE, title=unit),
        yaxis=dict(**_AXIS_STYLE, title="Latitude",
                   tickvals=[-90,-60,-30,0,30,60,90],
                   ticktext=["90°S","60°S","30°S","EQ","30°N","60°N","90°N"]),
        legend=dict(orientation="h", yanchor="bottom", y=-0.3, font=dict(color=_TEXT, size=11), bgcolor="rgba(0,0,0,0)"),
    )
    return fig


# ── 3D Globe ──────────────────────────────────────────────────────────────────

def make_3d_globe(
    lats: np.ndarray,
    lons: np.ndarray,
    values: np.ndarray,
    title: str = "Global View",
    unit: str = "°C",
    colorscale: str = "RdBu_r",
) -> go.Figure:
    """
    Orthographic globe projection using Scattergeo.
    """
    flat_lats, flat_lons, flat_vals = [], [], []
    for ri, lat in enumerate(lats):
        for ci, lon in enumerate(lons):
            flat_lats.append(float(lat))
            flat_lons.append(float(lon))
            flat_vals.append(float(values[ri, ci]))

    fig = go.Figure(go.Scattergeo(
        lat=flat_lats,
        lon=flat_lons,
        mode="markers",
        marker=dict(
            size=5,
            color=flat_vals,
            colorscale=colorscale,
            showscale=True,
            colorbar=dict(
                title=dict(text=unit, side="right"),
                tickfont=dict(color=_TEXT, size=10),
                bgcolor=_BG2,
            ),
            opacity=0.85,
            cmin=float(np.percentile(flat_vals, 2)),
            cmax=float(np.percentile(flat_vals, 98)),
        ),
        hovertemplate="Lat %{lat:.1f}° | Lon %{lon:.1f}°<br>%{marker.color:.2f} " + unit + "<extra></extra>",
        text=[f"{v:.1f} {unit}" for v in flat_vals],
    ))

    fig.update_geos(
        projection_type="orthographic",
        bgcolor=_BG,
        showland=True, landcolor="rgba(30,45,60,0.8)",
        showocean=True, oceancolor="rgba(5,20,40,0.9)",
        showcoastlines=True, coastlinecolor="rgba(255,255,255,0.15)",
        showlakes=False,
        showframe=False,
        lataxis_showgrid=True, lonaxis_showgrid=True,
        lataxis_gridcolor="rgba(255,255,255,0.05)",
        lonaxis_gridcolor="rgba(255,255,255,0.05)",
    )

    fig.update_layout(
        **_LAYOUT_BASE,
        title=dict(text=title, font=dict(size=14, color="#e2e8f0"), x=0.01),
        height=480,
        geo=dict(bgcolor=_BG),
        dragmode="pan",
    )
    return fig


# ── Comparison subplots ───────────────────────────────────────────────────────

def make_comparison(
    lats: np.ndarray,
    lons: np.ndarray,
    values1: np.ndarray,
    values2: np.ndarray,
    label1: str = "Period A",
    label2: str = "Period B",
    unit: str = "°C",
    colorscale: str = "thermal",
) -> go.Figure:
    """
    Side-by-side heatmaps (subplots) for two time periods.
    """
    cs = COLORSCALES.get(colorscale, colorscale)
    vmin = min(np.nanmin(values1), np.nanmin(values2))
    vmax = max(np.nanmax(values1), np.nanmax(values2))

    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=[label1, label2],
        horizontal_spacing=0.06,
    )

    def _hm(values, col):
        return go.Heatmap(
            x=lons, y=lats, z=values,
            colorscale=cs, zmin=vmin, zmax=vmax,
            showscale=(col == 2),
            colorbar=dict(
                x=1.02, title=dict(text=unit, side="right"),
                tickfont=dict(color=_TEXT, size=10),
                bgcolor=_BG2,
            ),
            hoverongaps=False, zsmooth="best",
            hovertemplate=f"Lat %{{y:.1f}}° | Lon %{{x:.1f}}°<br>%{{z:.2f}} {unit}<extra></extra>",
        )

    fig.add_trace(_hm(values1, 1), row=1, col=1)
    fig.add_trace(_hm(values2, 2), row=1, col=2)

    for annotation in fig.layout.annotations:
        annotation.update(font=dict(color="#e2e8f0", size=13))

    axis_cfg = dict(**_AXIS_STYLE, showticklabels=False)
    fig.update_layout(
        **_LAYOUT_BASE,
        height=300,
        xaxis=axis_cfg, xaxis2=axis_cfg,
        yaxis=axis_cfg, yaxis2=axis_cfg,
    )
    return fig


# ── Global anomaly bar (story) ────────────────────────────────────────────────

def make_anomaly_bar(
    years: list[int],
    anomalies: list[float],
    highlight_year: int | None = None,
) -> go.Figure:
    """
    Stripe-style global mean anomaly bar chart (1950–2024).
    Bars are coloured warm/cool; an optional year is highlighted in teal.
    """
    colors = []
    for i, (yr, a) in enumerate(zip(years, anomalies)):
        if yr == highlight_year:
            colors.append("#00d4aa")
        elif a > 0.5:
            colors.append("#ef4444")
        elif a > 0.2:
            colors.append("#f59e0b")
        elif a > 0:
            colors.append("rgba(239,68,68,0.5)")
        elif a > -0.1:
            colors.append("rgba(34,211,238,0.4)")
        else:
            colors.append("#3b82f6")

    fig = go.Figure(go.Bar(
        x=years, y=anomalies,
        marker_color=colors,
        marker_line_width=0,
        opacity=0.9,
        hovertemplate="%{x}: %{y:+.3f}°C<extra></extra>",
    ))
    fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.25)", width=1))
    fig.update_layout(
        **_LAYOUT_BASE,
        title=dict(text="Global Mean Temperature Anomaly vs 1950–1980 Baseline", font=dict(size=13, color="#e2e8f0"), x=0.01),
        height=240,
        xaxis=dict(**_AXIS_STYLE, title="Year"),
        yaxis=dict(**_AXIS_STYLE, title="Anomaly (°C)"),
        bargap=0.05,
    )
    return fig
