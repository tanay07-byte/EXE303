"""
data/analysis.py
─────────────────
Statistical analysis utilities for climate data:
  • Linear trend / regression
  • Anomaly detection (z-score based)
  • Baseline subtraction
  • Running mean smoothing
  • Correlation helpers
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats


# ── Trend Analysis ────────────────────────────────────────────────────────────

def linear_trend(values: np.ndarray | list) -> tuple[np.ndarray, float, float]:
    """
    Fit a linear trend to a 1-D array.

    Returns
    -------
    trend_line  : same length as values, the fitted line
    slope       : slope per index step
    r_squared   : goodness of fit (0–1)
    """
    y = np.asarray(values, dtype=float)
    x = np.arange(len(y))
    slope, intercept, r_value, _, _ = scipy_stats.linregress(x, y)
    trend_line = intercept + slope * x
    return trend_line, float(slope), float(r_value ** 2)


def trend_per_decade(values: np.ndarray, steps_per_year: int = 12) -> float:
    """
    Compute warming/cooling trend in units per decade.

    Parameters
    ----------
    values         : time-series array
    steps_per_year : 12 for monthly, 1 for annual
    """
    _, slope, _ = linear_trend(values)
    return round(slope * steps_per_year * 10, 3)


# ── Anomaly Detection ─────────────────────────────────────────────────────────

def z_score_anomalies(values: np.ndarray, threshold: float = 2.0) -> np.ndarray:
    """
    Return boolean mask where |z-score| >= threshold.
    """
    y = np.asarray(values, dtype=float)
    z = (y - np.nanmean(y)) / (np.nanstd(y) + 1e-12)
    return np.abs(z) >= threshold


def z_scores(values: np.ndarray) -> np.ndarray:
    """Return z-score array (standard deviations from mean)."""
    y = np.asarray(values, dtype=float)
    return (y - np.nanmean(y)) / (np.nanstd(y) + 1e-12)


def flag_anomalies(df: pd.DataFrame, value_col: str = "value", threshold: float = 2.0) -> pd.DataFrame:
    """
    Add 'z_score' and 'is_anomaly' columns to a DataFrame.
    """
    df = df.copy()
    vals = df[value_col].to_numpy()
    df["z_score"] = z_scores(vals)
    df["is_anomaly"] = np.abs(df["z_score"]) >= threshold
    df["anomaly_type"] = "normal"
    df.loc[df["z_score"] > threshold, "anomaly_type"] = "hot"
    df.loc[df["z_score"] < -threshold, "anomaly_type"] = "cold"
    return df


# ── Spatial Anomaly (vs baseline) ────────────────────────────────────────────

def spatial_anomaly(
    values: np.ndarray,
    baseline: np.ndarray,
) -> np.ndarray:
    """
    Compute cell-wise anomaly: values − baseline.
    Both arrays must have the same shape.
    """
    return np.asarray(values, dtype=float) - np.asarray(baseline, dtype=float)


def anomaly_stats(anomaly_grid: np.ndarray) -> dict:
    """
    Summary statistics of a 2-D anomaly grid.
    """
    flat = anomaly_grid.flatten()
    pos_frac = float(np.sum(flat > 0) / len(flat))
    return {
        "mean_anomaly": round(float(np.mean(flat)), 3),
        "max_anomaly":  round(float(np.max(flat)), 3),
        "min_anomaly":  round(float(np.min(flat)), 3),
        "pct_warming":  round(pos_frac * 100, 1),
        "pct_cooling":  round((1 - pos_frac) * 100, 1),
    }


# ── Smoothing ─────────────────────────────────────────────────────────────────

def running_mean(values: np.ndarray, window: int = 12) -> np.ndarray:
    """
    Centered running mean with edge padding.
    """
    y = np.asarray(values, dtype=float)
    kernel = np.ones(window) / window
    return np.convolve(y, kernel, mode="same")


# ── Seasonal Decomposition ────────────────────────────────────────────────────

def seasonal_anomaly(monthly_series: np.ndarray) -> np.ndarray:
    """
    Remove climatological seasonal cycle from a monthly time series.

    Parameters
    ----------
    monthly_series : 1-D array of length N*12

    Returns
    -------
    deseasoned array of the same length
    """
    y = np.asarray(monthly_series, dtype=float)
    n = len(y)
    clim = np.array([np.nanmean(y[m::12]) for m in range(12)])
    cycle = np.tile(clim, n // 12 + 1)[:n]
    return y - cycle


# ── Correlation ───────────────────────────────────────────────────────────────

def pearson_r(a: np.ndarray, b: np.ndarray) -> float:
    """Pearson correlation between two arrays of equal length."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    mask = ~(np.isnan(a) | np.isnan(b))
    if mask.sum() < 3:
        return float("nan")
    r, _ = scipy_stats.pearsonr(a[mask], b[mask])
    return round(float(r), 4)
