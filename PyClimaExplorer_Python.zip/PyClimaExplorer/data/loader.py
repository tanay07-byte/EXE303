"""
data/loader.py
──────────────
Handles loading of real NetCDF (.nc) files via Xarray, and generates
synthetic ERA5-style data when no file is provided (demo / hackathon mode).

Supported variables
-------------------
  temp       – 2m Air Temperature (°C)
  precip     – Total Precipitation (mm/day)
  wind       – 10m Wind Speed (m/s)
  pressure   – Mean Sea-Level Pressure (hPa)
  humidity   – Relative Humidity (%)
"""

from __future__ import annotations

import hashlib
from functools import lru_cache
from typing import Optional

import numpy as np
import pandas as pd

try:
    import xarray as xr
    HAS_XARRAY = True
except ImportError:
    HAS_XARRAY = False

# ── Constants ─────────────────────────────────────────────────────────────────

VARIABLE_META = {
    "temp":     {"label": "Surface Temperature",    "unit": "°C",     "cmap": "RdYlBu_r"},
    "precip":   {"label": "Precipitation",          "unit": "mm/day", "cmap": "Blues"},
    "wind":     {"label": "Wind Speed",             "unit": "m/s",    "cmap": "YlOrRd"},
    "pressure": {"label": "Sea-Level Pressure",     "unit": "hPa",    "cmap": "PuOr"},
    "humidity": {"label": "Relative Humidity",      "unit": "%",      "cmap": "BrBG"},
}

MONTH_NAMES = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December",
]

LOCATION_PRESETS = {
    "Varanasi, India":      ( 25.3,  83.0),
    "Amazon Basin, Brazil": ( -3.5, -60.0),
    "Arctic Ocean":         ( 80.0,   0.0),
    "Sahara Desert, Libya": ( 23.0,  13.0),
    "Antarctica":           (-75.0,   0.0),
    "Tokyo, Japan":         ( 35.7, 139.7),
    "New York, USA":        ( 40.7, -74.0),
    "London, UK":           ( 51.5,  -0.1),
    "Sydney, Australia":    (-33.9, 151.2),
}

# ── Synthetic data engine ─────────────────────────────────────────────────────

def _hash_seed(*args) -> int:
    """Deterministic seed from arbitrary arguments."""
    key = "_".join(str(a) for a in args)
    return int(hashlib.md5(key.encode()).hexdigest(), 16) % (2**31)


def _rng(*args) -> np.random.Generator:
    return np.random.default_rng(_hash_seed(*args))


def synthetic_value(lat: float, lon: float, year: int, month: int, variable: str) -> float:
    """
    Return a single synthetic climate value for a given point in space/time.

    The values are physically plausible (latitude gradient, seasonal cycle,
    long-term warming trend) but are NOT real observations.
    """
    rng = _rng(lat, lon, year, month, variable)
    noise = float(rng.normal(0, 1))

    lat_rad = np.radians(lat)

    if variable == "temp":
        lat_factor  = np.cos(lat_rad)                        # 0 at poles, 1 at equator
        season      = np.sin((month - 3) * np.pi / 6) * 15 * lat_factor
        trend       = (year - 1950) * 0.018                 # ~+0.18°C/decade
        base        = 30 * lat_factor - 15                  # −15°C poles → +30°C tropics
        return round(base + season + trend + noise * 3, 2)

    if variable == "precip":
        base   = max(0.0, 6.0 * np.cos(lat_rad) + noise * 2)
        season = max(0.0, np.sin((month - 3) * np.pi / 6) * 3 * np.cos(lat_rad))
        return round(max(0.0, base + season), 2)

    if variable == "wind":
        base  = 4.0 + abs(lat) * 0.08                      # stronger at higher latitudes
        noise_val = abs(noise) * 2.5
        return round(base + noise_val, 2)

    if variable == "pressure":
        base  = 1013.25
        lat_p = -5.0 * np.sin(2 * lat_rad)                 # ITCZ / subtropical highs
        return round(base + lat_p + noise * 5, 1)

    if variable == "humidity":
        base = 60 * np.cos(lat_rad)
        return round(float(np.clip(base + noise * 15, 10, 100)), 1)

    return 0.0


# ── 2-D spatial grid ──────────────────────────────────────────────────────────

@lru_cache(maxsize=64)
def get_spatial_grid(
    variable: str,
    year: int,
    month: int,
    n_lat: int = 36,
    n_lon: int = 72,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns (lats, lons, values) arrays for a global grid.

    Parameters
    ----------
    variable : one of VARIABLE_META keys
    year     : 1950–2024
    month    : 1–12
    n_lat    : number of latitude bands (default 36 → 5° resolution)
    n_lon    : number of longitude bands (default 72 → 5° resolution)

    Returns
    -------
    lats   : shape (n_lat,)    – latitude centres
    lons   : shape (n_lon,)    – longitude centres
    values : shape (n_lat, n_lon) – variable values
    """
    lats = np.linspace(87.5, -87.5, n_lat)
    lons = np.linspace(-177.5, 177.5, n_lon)
    values = np.array([
        [synthetic_value(lat, lon, year, month, variable) for lon in lons]
        for lat in lats
    ])
    return lats, lons, values


# ── 1-D time series ───────────────────────────────────────────────────────────

def get_time_series(
    lat: float,
    lon: float,
    variable: str,
    start_year: int = 2004,
    end_year: int = 2024,
    aggregation: str = "monthly",
) -> pd.DataFrame:
    """
    Returns a DataFrame with columns [date, value] for a single grid point.

    aggregation : 'monthly' | 'annual' | 'seasonal'
    """
    records = []
    for year in range(start_year, end_year + 1):
        for month in range(1, 13):
            v = synthetic_value(lat, lon, year, month, variable)
            records.append({"date": pd.Timestamp(year=year, month=month, day=15), "value": v})

    df = pd.DataFrame(records)

    if aggregation == "annual":
        df = df.set_index("date").resample("YE").mean().reset_index()
        df["date"] = df["date"].dt.year.astype(str)
    elif aggregation == "seasonal":
        df["season"] = df["date"].dt.month.map({
            12: "DJF", 1: "DJF", 2: "DJF",
            3: "MAM", 4: "MAM", 5: "MAM",
            6: "JJA", 7: "JJA", 8: "JJA",
            9: "SON", 10: "SON", 11: "SON",
        })
        df = df.groupby(["date", "season"])["value"].mean().reset_index()
        df["date"] = df["date"].dt.strftime("%Y") + " " + df["season"]
    else:
        df["date"] = df["date"].dt.strftime("%Y-%m")

    return df


def get_seasonal_climatology(
    lat: float,
    lon: float,
    variable: str,
    start_year: int = 2000,
    end_year: int = 2024,
) -> pd.DataFrame:
    """
    Returns monthly climatology (12-month average over the period).
    """
    records = {m: [] for m in range(1, 13)}
    for year in range(start_year, end_year + 1):
        for month in range(1, 13):
            records[month].append(synthetic_value(lat, lon, year, month, variable))

    return pd.DataFrame({
        "month": MONTH_NAMES,
        "value": [np.mean(records[m]) for m in range(1, 13)],
    })


# ── Zonal mean ────────────────────────────────────────────────────────────────

def get_zonal_mean(
    variable: str,
    year: int,
    month: int = 7,
    n_lat: int = 36,
) -> pd.DataFrame:
    """
    Returns latitude vs. zonal-mean value for a given year/month.
    """
    lats, lons, values = get_spatial_grid(variable, year, month, n_lat)
    return pd.DataFrame({"lat": lats, "value": values.mean(axis=1)})


# ── Global metrics ────────────────────────────────────────────────────────────

def global_metrics(variable: str, year: int, month: int) -> dict:
    """Compute summary statistics for a spatial snapshot."""
    _, _, values = get_spatial_grid(variable, year, month)
    flat = values.flatten()
    _, _, base = get_spatial_grid(variable, 1990, month)

    return {
        "mean":      round(float(np.mean(flat)), 2),
        "std":       round(float(np.std(flat)), 2),
        "min":       round(float(np.min(flat)), 2),
        "max":       round(float(np.max(flat)), 2),
        "anomaly":   round(float(np.mean(flat) - np.mean(base)), 2),
        "n_cells":   int(flat.size),
    }


# ── NetCDF loader (real data) ─────────────────────────────────────────────────

def load_netcdf(
    filepath: str,
    variable_name: str,
    time_index: int = 0,
) -> Optional[tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """
    Load a real NetCDF file and return (lats, lons, values).

    Parameters
    ----------
    filepath      : path to .nc file
    variable_name : name of the variable in the file (e.g. 't2m', 'tp')
    time_index    : which time slice to extract

    Returns None if xarray is not available or file can't be read.

    Example usage
    -------------
    >>> lats, lons, vals = load_netcdf("era5_temp.nc", "t2m", time_index=0)
    """
    if not HAS_XARRAY:
        return None
    try:
        ds = xr.open_dataset(filepath)
        da = ds[variable_name].isel(time=time_index) if "time" in ds[variable_name].dims else ds[variable_name]
        lat_name = next((n for n in da.dims if "lat" in n.lower()), None)
        lon_name = next((n for n in da.dims if "lon" in n.lower()), None)
        if lat_name is None or lon_name is None:
            return None
        lats = da[lat_name].values
        lons = da[lon_name].values
        values = da.values
        # Convert Kelvin → Celsius if needed
        if values.mean() > 150:
            values = values - 273.15
        return lats, lons, values
    except Exception:
        return None
